'use strict';
/**
 * تمام APIهای کتابخانه
 */
const db = require('./db');
const {
  hashPassword, verifyPassword, createToken, getUser,
  authCookie, clearCookie, publicUser,
} = require('./auth-util');

/* ---------- قواعد امانت ---------- */
const LOAN_DAYS = 14;      // مدت امانت
const MAX_ACTIVE = 3;      // حداکثر امانت همزمان برای هر عضو
const FINE_PER_DAY = 1000; // جریمه‌ی هر روز تأخیر (تومان)

const ACTIVE_LIKE = ['pending', 'active', 'return_requested'];

class ApiError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

/** تبدیل ارقام فارسی/عربی به لاتین */
function toEnDigits(s) {
  return String(s ?? '')
    .replace(/[۰-۹]/g, d => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
    .replace(/[٠-٩]/g, d => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)));
}
function toInt(v, def = null) {
  const n = parseInt(toEnDigits(v), 10);
  return Number.isFinite(n) ? n : def;
}

/* ---------- ابزارها ---------- */

function categoryOf(book) {
  return db.load().categories.find(c => c.id === book.categoryId) || null;
}

function borrowCount(bookId) {
  return db.load().loans.filter(l => l.bookId === bookId && ['active', 'return_requested', 'returned'].includes(l.status)).length;
}

function bookView(b) {
  const cat = categoryOf(b);
  return {
    id: b.id, title: b.title, author: b.author, translator: b.translator,
    publisher: b.publisher, pubYear: b.pubYear, isbn: b.isbn, shelf: b.shelf,
    description: b.description, totalCopies: b.totalCopies, availableCopies: b.availableCopies,
    createdAt: b.createdAt,
    category: cat ? { id: cat.id, name: cat.name, color: cat.color } : null,
    borrowCount: borrowCount(b.id),
    available: b.availableCopies > 0,
  };
}

function loanView(l, { withUser = false } = {}) {
  const data = db.load();
  const book = data.books.find(b => b.id === l.bookId);
  const now = Date.now();
  let daysLeft = null, fine = 0, overdue = false;
  if (l.dueAt && (l.status === 'active' || l.status === 'return_requested')) {
    daysLeft = Math.ceil((new Date(l.dueAt) - now) / 864e5);
    if (daysLeft < 0) { overdue = true; fine = Math.abs(daysLeft) * FINE_PER_DAY; }
  }
  const view = {
    id: l.id, bookId: l.bookId, status: l.status,
    requestedAt: l.requestedAt, borrowedAt: l.borrowedAt, dueAt: l.dueAt, returnedAt: l.returnedAt,
    daysLeft, overdue, fine,
    book: book ? { id: book.id, title: book.title, author: book.author, category: categoryOf(book) } : null,
  };
  if (withUser) {
    const u = data.users.find(x => x.id === l.userId);
    view.user = u ? { id: u.id, fullName: u.fullName, membershipCode: u.membershipCode } : null;
  }
  return view;
}

function parseCategoryInput(body) {
  const data = db.load();
  if (body.newCategoryName && body.newCategoryName.trim()) {
    const name = body.newCategoryName.trim();
    const exists = data.categories.find(c => c.name === name);
    if (exists) return exists.id;
    const cat = { id: db.nextId('categories'), name, color: body.newCategoryColor || '#8a6d4f' };
    data.categories.push(cat);
    return cat.id;
  }
  const cid = parseInt(body.categoryId, 10);
  return data.categories.find(c => c.id === cid) ? cid : null;
}

/* ---------- ثبت مسیرها ---------- */

function registerApi(add) {

  /* ============ احراز هویت ============ */

  add('POST', '/api/auth/register', (c) => {
    const data = db.load();
    const fullName = (c.body.fullName || '').trim();
    const email = (c.body.email || '').trim().toLowerCase();
    const phone = (c.body.phone || '').trim();
    const password = c.body.password || '';

    if (fullName.length < 3) throw new ApiError(400, 'نام و نام خانوادگی باید حداقل ۳ حرف باشد.');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) throw new ApiError(400, 'ایمیل معتبر نیست.');
    if (password.length < 6) throw new ApiError(400, 'رمز عبور باید حداقل ۶ کاراکتر باشد.');
    if (data.users.some(u => u.email.toLowerCase() === email)) throw new ApiError(400, 'این ایمیل قبلاً ثبت شده است.');

    const id = db.nextId('users');
    const user = {
      id, fullName, email, phone,
      passwordHash: hashPassword(password),
      role: 'member',
      membershipCode: 'MBR-' + (1000 + id),
      createdAt: new Date().toISOString(),
    };
    data.users.push(user);
    db.save();
    return { data: { user: publicUser(user) }, cookie: authCookie(createToken(user)), message: 'عضویت شما با موفقیت ثبت شد. خوش آمدید!' };
  });

  add('POST', '/api/auth/login', (c) => {
    const data = db.load();
    const email = (c.body.email || '').trim().toLowerCase();
    const user = data.users.find(u => u.email.toLowerCase() === email);
    if (!user || !verifyPassword(c.body.password || '', user.passwordHash)) {
      throw new ApiError(401, 'ایمیل یا رمز عبور اشتباه است.');
    }
    return { data: { user: publicUser(user) }, cookie: authCookie(createToken(user)), message: 'خوش آمدید!' };
  });

  add('POST', '/api/auth/logout', () => {
    return { data: { ok: true }, cookie: clearCookie() };
  });

  add('GET', '/api/auth/me', (c) => {
    return { data: { user: publicUser(c.user) } };
  });

  /* ============ عمومی ============ */

  add('GET', '/api/bootstrap', () => {
    const data = db.load();
    const cats = data.categories.map(cat => ({
      ...cat,
      count: data.books.filter(b => b.categoryId === cat.id).length,
    })).sort((a, b) => b.count - a.count);
    return {
      data: {
        categories: cats,
        stats: {
          books: data.books.length,
          copies: data.books.reduce((s, b) => s + b.totalCopies, 0),
          members: data.users.filter(u => u.role === 'member').length,
          activeLoans: data.loans.filter(l => l.status === 'active' || l.status === 'return_requested').length,
        },
        rules: { loanDays: LOAN_DAYS, maxActive: MAX_ACTIVE, finePerDay: FINE_PER_DAY },
      },
    };
  });

  add('GET', '/api/books', (c) => {
    const data = db.load();
    const q = (c.query.get('q') || '').trim();
    const cat = c.query.get('cat') || c.query.get('category');
    const availOnly = c.query.get('available') === '1';
    const sort = c.query.get('sort') || 'new';
    const page = Math.max(1, parseInt(c.query.get('page') || '1', 10));
    const limit = Math.min(48, parseInt(c.query.get('limit') || '12', 10));

    let items = data.books.slice();
    if (q) {
      const needle = q.toLowerCase();
      items = items.filter(b =>
        [b.title, b.author, b.translator, b.publisher, b.isbn]
          .some(f => (f || '').toLowerCase().includes(needle)));
    }
    if (cat && cat !== 'all') {
      const cid = parseInt(cat, 10);
      items = items.filter(b => b.categoryId === cid);
    }
    if (availOnly) items = items.filter(b => b.availableCopies > 0);

    if (sort === 'title') items.sort((a, b) => a.title.localeCompare(b.title, 'fa'));
    else if (sort === 'author') items.sort((a, b) => a.author.localeCompare(b.author, 'fa'));
    else if (sort === 'popular') items.sort((a, b) => borrowCount(b.id) - borrowCount(a.id));
    else items.sort((a, b) => b.id - a.id);

    const total = items.length;
    const pages = Math.max(1, Math.ceil(total / limit));
    const slice = items.slice((page - 1) * limit, page * limit);

    return { data: { items: slice.map(bookView), total, page, pages } };
  });

  add('GET', '/api/books/:id', (c) => {
    const data = db.load();
    const book = data.books.find(b => b.id === parseInt(c.params.id, 10));
    if (!book) throw new ApiError(404, 'کتاب مورد نظر پیدا نشد.');

    let mine = null;
    if (c.user) {
      const loan = data.loans.find(l =>
        l.userId === c.user.id && l.bookId === book.id && ACTIVE_LIKE.includes(l.status));
      if (loan) mine = { id: loan.id, status: loan.status };
    }
    const related = data.books
      .filter(b => b.categoryId === book.categoryId && b.id !== book.id)
      .sort((a, b) => borrowCount(b.id) - borrowCount(a.id))
      .slice(0, 4)
      .map(bookView);

    return { data: { book: bookView(book), mine, related } };
  });

  /* ============ پنل عضو ============ */

  add('GET', '/api/me/loans', (c) => {
    const data = db.load();
    const loans = data.loans
      .filter(l => l.userId === c.user.id)
      .sort((a, b) => new Date(b.requestedAt) - new Date(a.requestedAt))
      .map(l => loanView(l));
    const active = loans.filter(l => l.status === 'active' || l.status === 'return_requested').length;
    return { data: { loans, active, maxActive: MAX_ACTIVE } };
  }, 'auth');

  add('POST', '/api/me/loans', (c) => {
    const data = db.load();
    if (c.user.role !== 'member') throw new ApiError(403, 'فقط اعضا می‌توانند کتاب امانت بگیرند.');

    const bookId = toInt(c.body.bookId);
    const book = data.books.find(b => b.id === bookId);
    if (!book) throw new ApiError(404, 'کتاب مورد نظر پیدا نشد.');
    if (book.availableCopies <= 0) throw new ApiError(400, 'هم‌اکنون نسخه‌ی موجودی از این کتاب در کتابخانه نیست.');

    const mine = data.loans.filter(l => l.userId === c.user.id);
    if (mine.some(l => l.bookId === bookId && ACTIVE_LIKE.includes(l.status))) {
      throw new ApiError(400, 'شما همین حالا این کتاب را نزد خود دارید یا درخواست آن در انتظار تأیید است.');
    }
    const activeLike = mine.filter(l => ACTIVE_LIKE.includes(l.status)).length;
    if (activeLike >= MAX_ACTIVE) {
      throw new ApiError(400, `حداکثر ${MAX_ACTIVE} کتاب همزمان می‌توانید نزد خود داشته باشید (درخواست‌های در انتظار هم حساب می‌شوند).`);
    }

    const loan = {
      id: db.nextId('loans'),
      userId: c.user.id, bookId,
      status: 'pending',
      requestedAt: new Date().toISOString(),
      borrowedAt: null, dueAt: null, returnedAt: null,
    };
    data.loans.push(loan);
    db.save();
    return { data: { loan: loanView(loan) }, message: 'درخواست امانت ثبت شد و در انتظار تأیید مدیر است.' };
  }, 'auth');

  add('POST', '/api/me/loans/:id/return', (c) => {
    const data = db.load();
    const loan = data.loans.find(l => l.id === parseInt(c.params.id, 10) && l.userId === c.user.id);
    if (!loan) throw new ApiError(404, 'امانت مورد نظر پیدا نشد.');
    if (loan.status !== 'active') throw new ApiError(400, 'این امانت در وضعیت قابل بازگرداندن نیست.');
    loan.status = 'return_requested';
    db.save();
    return { data: { loan: loanView(loan) }, message: 'درخواست بازگرداندن ثبت شد. لطفاً کتاب را به میز امانت تحویل دهید.' };
  }, 'auth');

  /* ============ پنل مدیریت ============ */

  add('GET', '/api/admin/stats', () => {
    const data = db.load();
    const now = Date.now();
    const activeLoans = data.loans.filter(l => l.status === 'active' || l.status === 'return_requested');
    const overdue = activeLoans.filter(l => l.dueAt && new Date(l.dueAt) < now);
    const recent = data.loans
      .slice()
      .sort((a, b) => new Date(b.requestedAt) - new Date(a.requestedAt))
      .slice(0, 8)
      .map(l => loanView(l, { withUser: true }));
    const topBooks = data.books
      .map(b => ({ ...bookView(b) }))
      .sort((a, b) => b.borrowCount - a.borrowCount)
      .slice(0, 5);
    return {
      data: {
        books: data.books.length,
        copies: data.books.reduce((s, b) => s + b.totalCopies, 0),
        members: data.users.filter(u => u.role === 'member').length,
        activeLoans: activeLoans.length,
        pendingLoans: data.loans.filter(l => l.status === 'pending').length,
        overdueLoans: overdue.length,
        returnedLoans: data.loans.filter(l => l.status === 'returned').length,
        recent, topBooks,
      },
    };
  }, 'admin');

  add('GET', '/api/admin/books', (c) => {
    const data = db.load();
    const q = (c.query.get('q') || '').trim().toLowerCase();
    let items = data.books.slice();
    if (q) {
      items = items.filter(b =>
        [b.title, b.author, b.isbn].some(f => (f || '').toLowerCase().includes(q)));
    }
    items.sort((a, b) => b.id - a.id);
    return { data: { items: items.map(bookView) } };
  }, 'admin');

  add('POST', '/api/admin/books', (c) => {
    const data = db.load();
    const b = c.body;
    const title = (b.title || '').trim();
    const author = (b.author || '').trim();
    if (title.length < 2) throw new ApiError(400, 'عنوان کتاب را وارد کنید.');
    if (author.length < 2) throw new ApiError(400, 'نام نویسنده را وارد کنید.');
    const total = Math.max(1, toInt(b.totalCopies, 1) || 1);
    const categoryId = parseCategoryInput(b);
    if (!categoryId) throw new ApiError(400, 'دسته‌بندی را انتخاب کنید.');

    const book = {
      id: db.nextId('books'),
      title, author,
      translator: (b.translator || '').trim(),
      publisher: (b.publisher || '').trim(),
      pubYear: b.pubYear ? toInt(b.pubYear) : null,
      isbn: (b.isbn || '').trim(),
      categoryId,
      description: (b.description || '').trim(),
      totalCopies: total,
      availableCopies: total,
      shelf: (b.shelf || '').trim(),
      createdAt: new Date().toISOString(),
    };
    data.books.push(book);
    db.save();
    return { data: { book: bookView(book) }, message: `کتاب «${title}» به کتابخانه اضافه شد.` };
  }, 'admin');

  add('PUT', '/api/admin/books/:id', (c) => {
    const data = db.load();
    const book = data.books.find(b => b.id === parseInt(c.params.id, 10));
    if (!book) throw new ApiError(404, 'کتاب پیدا نشد.');
    const b = c.body;
    const title = (b.title || '').trim();
    const author = (b.author || '').trim();
    if (title.length < 2) throw new ApiError(400, 'عنوان کتاب را وارد کنید.');
    if (author.length < 2) throw new ApiError(400, 'نام نویسنده را وارد کنید.');
    const newTotal = Math.max(1, toInt(b.totalCopies, 1) || 1);
    const categoryId = parseCategoryInput(b);
    if (!categoryId) throw new ApiError(400, 'دسته‌بندی را انتخاب کنید.');

    // تنظیم موجودی: اگر کل نسخه‌ها زیاد شد، موجودی هم به همان اندازه زیاد شود
    const out = book.totalCopies - book.availableCopies; // نسخه‌های امانت‌رفته
    book.title = title;
    book.author = author;
    book.translator = (b.translator || '').trim();
    book.publisher = (b.publisher || '').trim();
    book.pubYear = b.pubYear ? toInt(b.pubYear) : null;
    book.isbn = (b.isbn || '').trim();
    book.categoryId = categoryId;
    book.description = (b.description || '').trim();
    book.shelf = (b.shelf || '').trim();
    book.totalCopies = newTotal;
    book.availableCopies = Math.max(0, Math.min(newTotal, newTotal - out));
    db.save();
    return { data: { book: bookView(book) }, message: `کتاب «${title}» به‌روزرسانی شد.` };
  }, 'admin');

  add('DELETE', '/api/admin/books/:id', (c) => {
    const data = db.load();
    const id = parseInt(c.params.id, 10);
    const book = data.books.find(b => b.id === id);
    if (!book) throw new ApiError(404, 'کتاب پیدا نشد.');
    if (data.loans.some(l => l.bookId === id && ACTIVE_LIKE.includes(l.status))) {
      throw new ApiError(400, 'این کتاب امانت فعال دارد و قابل حذف نیست. اول وضعیت امانت‌ها را ببندید.');
    }
    data.books = data.books.filter(b => b.id !== id);
    db.save();
    return { data: { ok: true }, message: `کتاب «${book.title}» حذف شد.` };
  }, 'admin');

  add('GET', '/api/admin/members', (c) => {
    const data = db.load();
    const q = (c.query.get('q') || '').trim().toLowerCase();
    let users = data.users.slice();
    if (q) {
      users = users.filter(u =>
        [u.fullName, u.email, u.membershipCode].some(f => (f || '').toLowerCase().includes(q)));
    }
    const items = users.map(u => ({
      ...publicUser(u),
      activeLoans: data.loans.filter(l => l.userId === u.id && (l.status === 'active' || l.status === 'return_requested')).length,
      pendingLoans: data.loans.filter(l => l.userId === u.id && l.status === 'pending').length,
      totalLoans: data.loans.filter(l => l.userId === u.id && ['active', 'return_requested', 'returned'].includes(l.status)).length,
    })).sort((a, b) => b.id - a.id);
    return { data: { items } };
  }, 'admin');

  add('GET', '/api/admin/members/:id/loans', (c) => {
    const data = db.load();
    const user = data.users.find(u => u.id === parseInt(c.params.id, 10));
    if (!user) throw new ApiError(404, 'عضو پیدا نشد.');
    const loans = data.loans
      .filter(l => l.userId === user.id)
      .sort((a, b) => new Date(b.requestedAt) - new Date(a.requestedAt))
      .map(l => loanView(l));
    return { data: { member: publicUser(user), loans } };
  }, 'admin');

  add('GET', '/api/admin/loans', (c) => {
    const data = db.load();
    const status = c.query.get('status') || 'all';
    let loans = data.loans.slice();
    if (status !== 'all') loans = loans.filter(l => l.status === status);
    loans.sort((a, b) => new Date(b.requestedAt) - new Date(a.requestedAt));
    return { data: { items: loans.map(l => loanView(l, { withUser: true })) } };
  }, 'admin');

  add('POST', '/api/admin/loans/:id/approve', (c) => {
    const data = db.load();
    const loan = data.loans.find(l => l.id === parseInt(c.params.id, 10));
    if (!loan) throw new ApiError(404, 'امانت پیدا نشد.');
    if (loan.status !== 'pending') throw new ApiError(400, 'این درخواست قبلاً بررسی شده است.');
    const book = data.books.find(b => b.id === loan.bookId);
    if (!book || book.availableCopies <= 0) throw new ApiError(400, 'نسخه‌ی موجودی از این کتاب در دسترس نیست.');
    loan.status = 'active';
    loan.borrowedAt = new Date().toISOString();
    loan.dueAt = new Date(Date.now() + LOAN_DAYS * 864e5).toISOString();
    book.availableCopies -= 1;
    db.save();
    return { data: { loan: loanView(loan, { withUser: true }) }, message: 'درخواست امانت تأیید شد.' };
  }, 'admin');

  add('POST', '/api/admin/loans/:id/reject', (c) => {
    const data = db.load();
    const loan = data.loans.find(l => l.id === parseInt(c.params.id, 10));
    if (!loan) throw new ApiError(404, 'امانت پیدا نشد.');
    if (loan.status !== 'pending') throw new ApiError(400, 'این درخواست قبلاً بررسی شده است.');
    loan.status = 'rejected';
    db.save();
    return { data: { loan: loanView(loan, { withUser: true }) }, message: 'درخواست امانت رد شد.' };
  }, 'admin');

  add('POST', '/api/admin/loans/:id/return', (c) => {
    const data = db.load();
    const loan = data.loans.find(l => l.id === parseInt(c.params.id, 10));
    if (!loan) throw new ApiError(404, 'امانت پیدا نشد.');
    if (loan.status !== 'active' && loan.status !== 'return_requested') {
      throw new ApiError(400, 'این امانت فعال نیست.');
    }
    const book = data.books.find(b => b.id === loan.bookId);
    loan.status = 'returned';
    loan.returnedAt = new Date().toISOString();
    if (book) book.availableCopies = Math.min(book.totalCopies, book.availableCopies + 1);
    db.save();
    return { data: { loan: loanView(loan, { withUser: true }) }, message: 'بازگشت کتاب ثبت شد.' };
  }, 'admin');

  add('POST', '/api/admin/categories', (c) => {
    const data = db.load();
    const name = (c.body.name || '').trim();
    if (name.length < 2) throw new ApiError(400, 'نام دسته را وارد کنید.');
    if (data.categories.some(x => x.name === name)) throw new ApiError(400, 'این دسته از قبل وجود دارد.');
    const cat = { id: db.nextId('categories'), name, color: (c.body.color || '#8a6d4f').trim() };
    data.categories.push(cat);
    db.save();
    return { data: { category: cat }, message: `دسته‌ی «${name}» ساخته شد.` };
  }, 'admin');

  add('DELETE', '/api/admin/categories/:id', (c) => {
    const data = db.load();
    const id = parseInt(c.params.id, 10);
    const cat = data.categories.find(x => x.id === id);
    if (!cat) throw new ApiError(404, 'دسته پیدا نشد.');
    if (data.books.some(b => b.categoryId === id)) throw new ApiError(400, 'این دسته کتاب دارد و قابل حذف نیست.');
    data.categories = data.categories.filter(x => x.id !== id);
    db.save();
    return { data: { ok: true }, message: `دسته‌ی «${cat.name}» حذف شد.` };
  }, 'admin');

  return { LOAN_DAYS, MAX_ACTIVE, FINE_PER_DAY };
}

module.exports = registerApi;
module.exports.ApiError = ApiError;
module.exports.RULES = { LOAN_DAYS, MAX_ACTIVE, FINE_PER_DAY };
