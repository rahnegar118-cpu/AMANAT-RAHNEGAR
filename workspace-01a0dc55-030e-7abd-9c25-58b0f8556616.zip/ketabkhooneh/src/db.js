'use strict';
/**
 * دیتابیس JSON کتابخانه — بدون هیچ وابستگی خارجی
 * داده‌ها در پوشه data/library.json ذخیره می‌شود
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { hashPassword } = require('./password');

const DATA_DIR = path.join(__dirname, '..', 'data');
const DB_FILE = path.join(DATA_DIR, 'library.json');

let db = null;

/* ---------------- داده‌های اولیه (Seed) ---------------- */

function seedCategories() {
  return [
    { id: 1, name: 'رمان و داستان',      color: '#b0533c' },
    { id: 2, name: 'شعر و ادبیات کلاسیک', color: '#8d5b74' },
    { id: 3, name: 'فلسفه',               color: '#4f6b63' },
    { id: 4, name: 'تاریخ',               color: '#7a6547' },
    { id: 5, name: 'روان‌شناسی',          color: '#a06a2c' },
    { id: 6, name: 'علمی',                color: '#3f6273' },
    { id: 7, name: 'کودک و نوجوان',       color: '#c98a45' },
    { id: 8, name: 'کامپیوتر و فناوری',   color: '#565e7d' },
  ];
}

function seedBooks() {
  // [عنوان، نویسنده، مترجم، ناشر، سال، دسته، کل نسخه، موجود، قفسه، توضیح]
  const rows = [
    ['سووشون', 'سیمین دانشور', '', 'نشر نو', 1348, 1, 5, 4, 'A1-3', 'روایت یوسف و زینب در شیرازِ روزهای اشغال؛ مشهورترین رمان فارسی درباره‌ی مقاومت، عشق و آزادی.'],
    ['بوف کور', 'صادق هدایت', '', 'انتشارات امیرکبیر', 1311, 1, 4, 4, 'A1-1', 'مشهورترین اثر صادق هدایت؛ روایت خفقان و تنهایی یک مرد در جست‌وجوی رهایی.'],
    ['کلیدر', 'محمود دولت‌آبادی', '', 'نشر معاصر', 1362, 1, 3, 3, 'A2-5', 'حماسه‌ای بلند از زندگی مردمان خراسان؛ یکی از طولانی‌ترین رمان‌های زبان فارسی.'],
    ['صد سال تنهایی', 'گابریل گارسیا مارکز', 'بهمن فرزانه', 'نشر نی', 1363, 1, 4, 3, 'A2-2', 'روایت شش نسل از خاندان بوئندیا در ماکوندو؛ شاهکار سبک رئالیسم جادویی.'],
    ['مسخ', 'فرانتس کافکا', 'صادق هدایت', 'نشر فروغ', 1327, 1, 3, 3, 'A2-3', 'گریگور سامسا یک روز صبح از خوابی آشفته بیدار می‌شود و خود را تغییر یافته می‌بیند؛ مشهورترین داستان کافکا با ترجمه‌ی صادق هدایت.'],
    ['چشم‌هایش', 'بزرگ علوی', '', 'انتشارات خوارزمی', 1351, 1, 2, 2, 'A1-4', 'رمان استاد ماکان و ماه‌دخت؛ داستان عشق، هنر و آزادی در روزگار تنگستان.'],
    ['شازده کوچولو', 'آنتوان دو سنت‌اگزوپری', 'احمد شاملو', 'نشر علمی و فرهنگی', 1354, 1, 4, 4, 'A3-1', 'پرتره‌ی شاعرانه‌ی یک کوچولو از سیاره‌ای دیگر؛ داستانی برای همه‌ی سنین درباره‌ی عشق و مسئولیت.'],
    ['همسایه‌ها', 'احمد محمود', '', 'نشر مرکز', 1374, 1, 2, 2, 'A3-2', 'اولین رمان احمد محمود؛ روایت زندگی مردمانی بی‌نام در محله‌ای جنوبی.'],
    ['دیوان حافظ', 'حافظ شیرازی', '', 'انتشارات پیام', null, 2, 6, 6, 'B1-1', 'دیوان کامل خواجه شمس‌الدین محمد حافظ شیرازی؛ غزل‌هایی که قرن‌ها همراه جان فارسی‌زبانان بوده است.'],
    ['گلستان', 'سعدی', '', 'نشر ققنوس', null, 2, 4, 4, 'B1-2', 'شاهکار نثر فارسی؛ حکایت‌هایی کوتاه از عشق، اخلاق و دانایی.'],
    ['دیوان شمس تبریزی', 'مولانا جلال‌الدین بلخی', '', 'نشر نی', null, 2, 5, 5, 'B1-3', 'غزل‌های شوریده‌ی مولانا؛ جهانی از عشق، شور و معنا.'],
    ['شاهنامه', 'ابوالقاسم فردوسی', '', 'نشر سخن', null, 2, 3, 3, 'B2-1', 'حماسه‌ی ملی ایران‌زمین؛ سی سال سخنوری فردوسی برای ایران و زبان پارسی.'],
    ['تاریخ فلسفه غرب', 'برتراند راسل', 'نجف دریابندری', 'انتشارات علمی و فرهنگی', 1373, 3, 3, 3, 'C1-1', 'مرور جامع و خوانا philosophical از پیشاسقراطیان تا قرن بیستم با قلم برتراند راسل و ترجمه‌ی نجف دریابندری.'],
    ['دنیای سوفی', 'یوستین گاردر', 'حسن کامشاد', 'نشر نی', 1376, 3, 3, 3, 'C1-2', 'رمانی درباره‌ی تاریخ فلسفه؛ سوفی نامه‌هایی دریافت می‌کند که دنیای اندیشه را پیش رویش می‌گشاید.'],
    ['ایران باستان', 'حسن پیرنیا', '', 'انتشارات دنیای کتاب', 1372, 4, 4, 4, 'C2-1', 'مرجع مشهور تاریخ ایران باستان؛ از مادها تا ساسانیان با روایت حسن پیرنیا (مشدی علی‌اکبر).'],
    ['انسان خردمند', 'یووال نوح هراری', 'نیک گوگل', 'نشر ققنوس', 1395, 4, 3, 3, 'C2-2', 'تاریخ مختصر نوع بشر از انقلاب شناختی تا امروز؛ پرفروش‌ترین کتاب تاریخِ دهه‌ی اخیر.'],
    ['عادت‌های اتمی', 'جیمز کلیر', 'سیده مریم حسینی', 'نشر نوین', 1398, 5, 4, 3, 'D1-1', 'چگونه تغییرهای کوچک، نتایج شگرف می‌آفرینند؛ راهنمای عملی ساختن عادت‌های خوب و شکستن عادت‌های بد.'],
    ['اثر مرکب', 'دارن هاردی', '', 'نشر نوین', 1397, 5, 2, 2, 'D1-2', 'قدرت اثر تجمعی؛ تصمیم‌های کوچکِ روزانه چگونه مثل برف‌توله بزرگ می‌شوند.'],
    ['تاریخ مختصر زمان', 'استیون هاوکینگ', '', 'نشر علمی', 1385, 6, 3, 3, 'D2-1', 'از انفجار بزرگ تا سیاه‌چاله‌ها؛ هاوکینگ در کتابی کوتاه رازهای کیهان را می‌گشاید.'],
    ['کیهان', 'کارل سیگن', '', 'نشر ققنوس', 1377, 6, 2, 2, 'D2-2', 'سفر شاعرانه‌ی کارل سیگن میان ستارگان؛ کتابی که میلیون‌ها نفر را عاشق نجوم کرد.'],
    ['ماهی سیاه کوچولو', 'صمد بهرنگی', '', 'انتشارات امیرکبیر', 1347, 7, 5, 5, 'E1-1', 'سفر ماهی سیاه کوچولو به انتهای رودخانه؛ داستان جاودان درباره‌ی پرسشگری و آزادی.'],
    ['قصه‌های مجید', 'هوشنگ مرادی کرمانی', '', 'نشر مرکز', 1370, 7, 4, 4, 'E1-2', 'قصه‌های صمیمی از یک پسر کرمانی؛ خاطره‌هایی از کودکی، خانواده و دوستی.'],
    ['کد تمیز', 'رابرت سی. مارتین', '', 'نشر نص', 1396, 8, 2, 2, 'E2-1', 'درس‌های استادِ کار در نگارش کد خوانا و قابل نگهداری؛ از متون کلاسیک مهندسی نرم‌افزار.'],
    ['مقدمه‌ای بر الگوریتم‌ها', 'توماس اچ. کورمن', '', 'نشر نص', 1399, 8, 2, 2, 'E2-2', 'مرجع کلاسیک دانشگاهی طراحی و تحلیل الگوریتم‌ها؛ از مرتب‌سازی تا گراف.'],
  ];
  // جایگزینی واژه‌ی لاتین اشتباه در توضیح
  return rows.map((r, i) => ({
    id: i + 1,
    title: r[0], author: r[1], translator: r[2], publisher: r[3], pubYear: r[4],
    categoryId: r[5], totalCopies: r[6], availableCopies: r[7], shelf: r[8],
    description: r[9].replace('philosophical', 'فلسفی'),
    isbn: '978-600-' + String(1000 + i * 37).padStart(4, '0') + '-' + String((i * 7) % 90 + 10),
    createdAt: new Date(Date.now() - (24 - i) * 36e5 * 24).toISOString(),
  }));
}

function seedUsers() {
  return [
    {
      id: 1,
      fullName: 'مدیر کتابخانه',
      email: 'admin@ketabkhooneh.ir',
      passwordHash: hashPassword('admin1234'),
      role: 'admin',
      membershipCode: 'STF-1001',
      phone: '021-88776655',
      createdAt: new Date(Date.now() - 200 * 36e5 * 24).toISOString(),
    },
    {
      id: 2,
      fullName: 'سارا محمدی',
      email: 'member@ketabkhooneh.ir',
      passwordHash: hashPassword('member1234'),
      role: 'member',
      membershipCode: 'MBR-1002',
      phone: '0912-0000000',
      createdAt: new Date(Date.now() - 90 * 36e5 * 24).toISOString(),
    },
    {
      id: 3,
      fullName: 'رضا کریمی',
      email: 'reza@ketabkhooneh.ir',
      passwordHash: hashPassword('member1234'),
      role: 'member',
      membershipCode: 'MBR-1003',
      phone: '',
      createdAt: new Date(Date.now() - 45 * 36e5 * 24).toISOString(),
    },
    {
      id: 4,
      fullName: 'مریم احمدی',
      email: 'maryam@ketabkhooneh.ir',
      passwordHash: hashPassword('member1234'),
      role: 'member',
      membershipCode: 'MBR-1004',
      phone: '',
      createdAt: new Date(Date.now() - 20 * 36e5 * 24).toISOString(),
    },
  ];
}

function daysAgo(n) { return new Date(Date.now() - n * 864e5).toISOString(); }
function daysFromNow(n) { return new Date(Date.now() + n * 864e5).toISOString(); }

function seedLoans() {
  return [
    // امانت فعال سارا: سووشون (۵ روز پیش)
    { id: 1, userId: 2, bookId: 1, status: 'active', requestedAt: daysAgo(6), borrowedAt: daysAgo(5), dueAt: daysFromNow(9), returnedAt: null },
    // امانت فعال رضا: صد سال تنهایی (کمی تأخیر دارد)
    { id: 2, userId: 3, bookId: 4, status: 'active', requestedAt: daysAgo(20), borrowedAt: daysAgo(19), dueAt: daysAgo(5), returnedAt: null },
    // درخواست در انتظار مریم: انسان خردمند
    { id: 3, userId: 4, bookId: 16, status: 'pending', requestedAt: daysAgo(1), borrowedAt: null, dueAt: null, returnedAt: null },
    // درخواست در انتظار سارا: عادت‌های اتمی
    { id: 4, userId: 2, bookId: 17, status: 'pending', requestedAt: daysAgo(0), borrowedAt: null, dueAt: null, returnedAt: null },
    // بازگردانده‌شده: دیوان شمس
    { id: 5, userId: 2, bookId: 11, status: 'returned', requestedAt: daysAgo(45), borrowedAt: daysAgo(44), dueAt: daysAgo(30), returnedAt: daysAgo(29) },
    // بازگرداندنی: ماهی سیاه کوچولو (مریم)
    { id: 6, userId: 4, bookId: 21, status: 'return_requested', requestedAt: daysAgo(12), borrowedAt: daysAgo(11), dueAt: daysFromNow(3), returnedAt: null },
    // بازگردانده‌شده قدیمی رضا
    { id: 7, userId: 3, bookId: 13, status: 'returned', requestedAt: daysAgo(60), borrowedAt: daysAgo(59), dueAt: daysAgo(45), returnedAt: daysAgo(43) },
  ];
}

/* ---------------- مدیریت دیتابیس ---------------- */

function load() {
  if (db) return db;
  if (fs.existsSync(DB_FILE)) {
    db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
  } else {
    db = {
      settings: { authSecret: crypto.randomBytes(32).toString('hex'), libraryName: 'کتابخانه سپید' },
      users: seedUsers(),
      categories: seedCategories(),
      books: seedBooks(),
      loans: seedLoans(),
    };
    save();
    console.log('🌱 دیتابیس با داده‌های نمونه ساخته شد: ' + DB_FILE);
  }
  return db;
}

function save() {
  if (!db) return;
  const tmp = DB_FILE + '.tmp';
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.writeFileSync(tmp, JSON.stringify(db, null, 1), 'utf8');
  fs.renameSync(tmp, DB_FILE);
}

function nextId(coll) {
  return db[coll].reduce((m, x) => Math.max(m, x.id), 0) + 1;
}

module.exports = { load, save, nextId };
