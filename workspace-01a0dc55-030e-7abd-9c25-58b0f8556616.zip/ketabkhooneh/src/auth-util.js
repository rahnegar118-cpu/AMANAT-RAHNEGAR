'use strict';
/**
 * احراز هویت — هش رمز عبور با scrypt و توکن امضاشده با HMAC (بدون وابستگی)
 */
const crypto = require('crypto');
const db = require('./db');

const COOKIE_NAME = 'kk_token';
const TOKEN_TTL = 30 * 24 * 3600; // ۳۰ روز

/* ---------- رمز عبور (از ماژول مستقل password) ---------- */
const { hashPassword, verifyPassword } = require('./password');

/* ---------- توکن ---------- */

function b64url(buf) {
  return Buffer.from(buf).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
function b64urlJson(obj) { return b64url(JSON.stringify(obj)); }

function createToken(user) {
  const secret = db.load().settings.authSecret;
  const payload = b64urlJson({ uid: user.id, role: user.role, exp: Math.floor(Date.now() / 1000) + TOKEN_TTL });
  const sig = crypto.createHmac('sha256', secret).update(payload).digest();
  return payload + '.' + b64url(sig);
}

function verifyToken(token) {
  try {
    const secret = db.load().settings.authSecret;
    const [payload, sig] = token.split('.');
    if (!payload || !sig) return null;
    const expect = crypto.createHmac('sha256', secret).update(payload).digest();
    const got = Buffer.from(sig.replace(/-/g, '+').replace(/_/g, '/'), 'base64');
    if (expect.length !== got.length || !crypto.timingSafeEqual(expect, got)) return null;
    const data = JSON.parse(Buffer.from(payload.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8'));
    if (!data.exp || data.exp < Math.floor(Date.now() / 1000)) return null;
    return db.load().users.find(u => u.id === data.uid) || null;
  } catch {
    return null;
  }
}

/* ---------- کوکی ---------- */

function parseCookies(req) {
  const out = {};
  const header = req.headers.cookie;
  if (!header) return out;
  for (const part of header.split(';')) {
    const idx = part.indexOf('=');
    if (idx > -1) out[part.slice(0, idx).trim()] = decodeURIComponent(part.slice(idx + 1).trim());
  }
  return out;
}

/** کاربر فعلی درخواست را برمی‌گرداند (یا null) */
function getUser(req) {
  const token = parseCookies(req)[COOKIE_NAME];
  return token ? verifyToken(token) : null;
}

function authCookie(token) {
  return `${COOKIE_NAME}=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${TOKEN_TTL}`;
}
function clearCookie() {
  return `${COOKIE_NAME}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0`;
}

/** نسخه‌ی عمومی اطلاعات کاربر (بدون هش رمز) */
function publicUser(u) {
  if (!u) return null;
  return {
    id: u.id, fullName: u.fullName, email: u.email, role: u.role,
    membershipCode: u.membershipCode, phone: u.phone || '', createdAt: u.createdAt,
  };
}

module.exports = {
  COOKIE_NAME, TOKEN_TTL,
  hashPassword, verifyPassword,
  createToken, verifyToken,
  parseCookies, getUser, authCookie, clearCookie, publicUser,
};
