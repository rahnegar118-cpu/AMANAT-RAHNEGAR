'use strict';
/**
 * هش و بررسی رمز عبور — scrypt (بدون وابستگی، بدون import حلقه‌ای)
 */
const crypto = require('crypto');

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(String(password), salt, 64).toString('hex');
  return 'scrypt$' + salt + '$' + hash;
}

function verifyPassword(password, stored) {
  try {
    const [algo, salt, hash] = String(stored).split('$');
    if (algo !== 'scrypt') return false;
    const check = crypto.scryptSync(String(password), salt, 64);
    return crypto.timingSafeEqual(check, Buffer.from(hash, 'hex'));
  } catch {
    return false;
  }
}

module.exports = { hashPassword, verifyPassword };
