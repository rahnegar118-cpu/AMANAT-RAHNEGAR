/* ================= کتابخانه سپید — اپلیکیشن تک‌صفحه‌ای ================= */
'use strict';

/* ---------- ابزارها ---------- */
const $ = (s, p) => (p || document).querySelector(s);
const $$ = (s, p) => Array.from((p || document).querySelectorAll(s));

const fa = v => String(v).replace(/[0-9]/g, d => '۰۱۲۳۴۵۶۷۸۹'[+d]);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const money = n => fa(n.toLocaleString('en-US').replace(/,/g, '٬')) + ' تومان';

function fmtDate(iso) {
  if (!iso) return '—';
  try { return new Date(iso).toLocaleDateString('fa-IR', { year: 'numeric', month: 'long', day: 'numeric' }); }
  catch { return '—'; }
}
function fmtDateShort(iso) {
  if (!iso) return '—';
  try { return new Date(iso).toLocaleDateString('fa-IR'); } catch { return '—'; }
}
function shade(hex, pct) {
  try {
    const n = parseInt(hex.slice(1), 16);
    let r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
    const t = pct < 0 ? 0 : 255, p = Math.abs(pct) / 100;
    r = Math.round((t - r) * p + r); g = Math.round((t - g) * p + g); b = Math.round((t - b) * p + b);
    return '#' + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
  } catch { return '#8a6d4f'; }
}
function debounce(fn, ms) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }

/* ---------- آیکون‌ها ---------- */
const I = {
  book: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20V4H6.5A2.5 2.5 0 0 0 4 6.5v13zM4 19.5A2.5 2.5 0 0 0 6.5 22H20v-5"/></svg>',
  layers: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 2 2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>',
  users: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
  bookmark: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z"/></svg>',
  search: '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>',
  plus: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M12 5v14M5 12h14"/></svg>',
  edit: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"/></svg>',
  trash: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m3 0v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/></svg>',
  eye: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>',
  clock: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>',
  check: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6"><path d="M20 6 9 17l-5-5"/></svg>',
};
const LOGO = '<svg class="logo" viewBox="0 0 64 64"><rect width="64" height="64" rx="13" fill="#c9a25e"/><path d="M14 18c6-3 12-3 17 0v28c-5-3-11-3-17 0V18zm36 0c-6-3-12-3-17 0v28c5-3 11-3 17 0V18z" fill="#352413"/></svg>';

/* ---------- وضعیت سراسری ---------- */
const state = {
  user: null,
  cats: [],
  stats: null,
  rules: { loanDays: 14, maxActive: 3, finePerDay: 1000 },
  pendingCount: 0,
};

const LOAN_FA = {
  pending: 'در انتظار تأیید',
  active: 'امانت فعال',
  return_requested: 'درخواست بازگشت',
  returned: 'بازگشت داده شد',
  rejected: 'رد شده',
};
const badgeCls = {
  pending: 'badge-pending', active: 'badge-active',
  return_requested: 'badge-active', returned: 'badge-returned', rejected: 'badge-rejected',
};
const statusBadge = s => `<span class="badge ${badgeCls[s] || ''}"><span class="badge-dot"></span>${LOAN_FA[s] || s}</span>`;

/* ---------- API ---------- */
async function api(path, opts = {}) {
  const res = await fetch(path, {
    method: opts.method || 'GET',
    headers: opts.body ? { 'Content-Type': 'application/json' } : {},
    body: opts.body ? JSON.stringify(opts.body) : undefined,
    credentials: 'same-origin',
  });
  let json = null;
  try { json = await res.json(); } catch { /* خالی */ }
  if (!res.ok || !json || json.ok === false) throw new Error((json && json.error) || 'خطا در ارتباط با سرور');
  return json;
}

/* ---------- توست و مودال ---------- */
function toast(msg, type = 'ok') {
  const el = document.createElement('div');
  el.className = 'toast ' + type;
  el.innerHTML = (type === 'err' ? '⚠️ ' : '✅ ') + esc(msg);
  $('#toast-wrap').appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; el.style.transition = '.4s'; setTimeout(() => el.remove(), 400); }, 3600);
}
function openModal(html, wide) {
  $('#modal-root').innerHTML =
    `<div class="overlay"><div class="modal ${wide ? 'wide' : ''}"><button class="x" data-act="modal-close" aria-label="بستن">✕</button>${html}</div></div>`;
}
function closeModal() { $('#modal-root').innerHTML = ''; }
let confirmCb = null;
function confirmModal(title, msg, cb) {
  confirmCb = cb;
  openModal(`<h2>${esc(title)}</h2><p class="muted">${esc(msg)}</p>
    <div style="display:flex;gap:10px;margin-top:24px">
      <button class="btn btn-danger" data-act="confirm-yes">بله، انجام بده</button>
      <button class="btn btn-soft" data-act="modal-close">انصراف</button>
    </div>`);
}

/* ---------- کامپوننت‌ها ---------- */
function catColor(b) { return (b.category && b.category.color) || '#8a6d4f'; }

function coverHTML(b, cls = '') {
  const c = catColor(b);
  return `<div class="cover ${cls}" style="background:linear-gradient(155deg, ${shade(c, 24)}, ${c} 52%, ${shade(c, -18)})">
    <div class="cover-inner">
      <div class="cover-orn">✦ ❖ ✦</div>
      <div class="cover-title">${esc(b.title)}</div>
      <div class="cover-rule"></div>
      <div class="cover-author">${esc(b.author)}</div>
    </div>
  </div>`;
}
function miniCover(b, txt) {
  const c = catColor(b);
  return `<div class="mini-cover" style="background:linear-gradient(150deg, ${shade(c, 22)}, ${shade(c, -14)})">${esc(txt || ' ')}</div>`;
}
function bookCard(b) {
  return `<div class="book-card">
    <a class="cover-wrap" href="#/book/${b.id}" aria-label="${esc(b.title)}">
      ${coverHTML(b)}
      <span class="badge ${b.available ? 'badge-ok' : 'badge-out'}"><span class="badge-dot"></span>${b.available ? 'موجود' : 'امانت‌رفته'}</span>
    </a>
    <div>
      <div class="b-title"><a href="#/book/${b.id}">${esc(b.title)}</a></div>
      <div class="b-author">${esc(b.author)}</div>
    </div>
  </div>`;
}
function loading() { return '<div class="loading">در حال بارگذاری<span class="dots"></span></div>'; }
function emptyState(txt, icon = '📚') {
  return `<div class="empty"><div class="big">${icon}</div>${esc(txt)}</div>`;
}

/* ---------- هدر و فوتر ---------- */
function renderHeader() {
  const u = state.user;
  const links = [
    ['/', 'خانه'],
    ['/books', 'کتاب‌ها'],
  ];
  const cur = currentPath();
  $('#site-header').innerHTML = `
  <div class="header-inner">
    <a class="brand" href="#/">${LOGO}
      <div><div class="t1">کتابخانه سپید</div><div class="t2">SEPID LIBRARY</div></div>
    </a>
    <button class="burger" data-act="burger" aria-label="منو">☰</button>
    <nav class="main-nav" id="main-nav">
      ${links.map(([h, t]) => `<a href="#${h}" class="${cur === h ? 'active' : ''}">${t}</a>`).join('')}
      ${u ? `<a href="#/account" class="${cur === '/account' ? 'active' : ''}">پنل من</a>` : ''}
      ${u && u.role === 'admin' ? `<a href="#/admin" class="${cur.startsWith('/admin') ? 'active' : ''}">پنل مدیریت</a>` : ''}
    </nav>
    <div class="nav-user">
      ${u ? `
        <a class="user-chip" href="#/account"><span class="avatar">${esc(u.fullName.trim().charAt(0))}</span>${esc(u.fullName.split(' ')[0])}</a>
        <button class="btn btn-sm btn-outline" style="border-color:rgba(193,154,75,.5);color:#f4e8cd" data-act="logout">خروج</button>
      ` : `
        <a class="btn btn-sm btn-gold" href="#/login">ورود</a>
        <a class="btn btn-sm btn-outline" style="border-color:rgba(193,154,75,.5);color:#f4e8cd" href="#/register">عضویت</a>
      `}
    </div>
  </div>`;
}
function renderFooter() {
  $('#site-footer').innerHTML = `
  <div class="footer-inner">
    <div>
      <div class="footer-logo">${LOGO}<b style="font-size:1.05rem">کتابخانه سپید</b></div>
      <p>کتابخانه‌ی عمومی سپید از سال ۱۳۹۲ خانه‌ی کتاب‌خوان‌های شهر ما بوده است؛ با بیش از ${fa(state.stats ? state.stats.books : '—')} عنوان کتاب در موضوع‌های گوناگون، همه‌چیز برای یک عصر دل‌نشین خواندن آماده است.</p>
    </div>
    <div>
      <h4>دسترسی سریع</h4>
      <ul>
        <li><a href="#/books">کاتالوگ کتاب‌ها</a></li>
        <li><a href="#/register">عضویت در کتابخانه</a></li>
        <li><a href="#/account">پنل اعضا</a></li>
      </ul>
    </div>
    <div>
      <h4>اطلاعات تماس</h4>
      <ul>
        <li>📍 خیابان کتاب، کوچه‌ی دانا، پلاک ۱۲</li>
        <li>🕐 شنبه تا پنجشنبه — ۸ صبح تا ۸ شب</li>
        <li>📞 ۸۸۷۷-۶۶۵۵ (۰۲۱)</li>
        <li>✉️ info@ketabkhooneh.ir</li>
      </ul>
    </div>
  </div>
  <div class="footer-bottom">ساخته‌شده با ❤ برای دوستداران کتاب — کتابخانه سپید ۱۴۰۴</div>`;
}

/* ---------- روتر ---------- */
function currentPath() {
  const h = (location.hash || '#/').slice(1);
  return '/' + h.split('?')[0].split('/').filter(Boolean).join('/');
}
function hashQuery() {
  const h = (location.hash || '').slice(1);
  const q = h.split('?')[1];
  return new URLSearchParams(q || '');
}
function nav(hash) { location.hash = hash; }

async function route() {
  const path = currentPath();
  const segs = path.split('/').filter(Boolean);
  const view = $('#view');
  $('#main-nav') && $('#main-nav').classList.remove('open');
  renderHeader();

  try {
    if (segs.length === 0) return await viewHome(view);
    if (segs[0] === 'books') return await viewBooks(view, hashQuery());
    if (segs[0] === 'book' && segs[1]) return await viewBook(view, segs[1]);
    if (segs[0] === 'login') return viewLogin(view, hashQuery());
    if (segs[0] === 'register') return viewRegister(view, hashQuery());
    if (segs[0] === 'account') return await viewAccount(view);
    if (segs[0] === 'admin') return await viewAdmin(view, segs[1] || 'dash');
    view.innerHTML = `<div class="container">${emptyState('چنین صفحه‌ای پیدا نشد.', '🧭')}<p class="center" style="margin-bottom:40px"><a class="btn btn-primary" href="#/">بازگشت به خانه</a></p></div>`;
    document.title = 'پیدا نشد — کتابخانه سپید';
  } catch (err) {
    view.innerHTML = `<div class="container"><div class="empty" style="padding:70px 20px"><div class="big">⚠️</div>${esc(err.message)}</div></div>`;
  }
}

/* ================= صفحه‌ی خانه ================= */
async function viewHome(view) {
  document.title = 'کتابخانه سپید — خانه';
  let stats = state.stats;
  if (!stats) { const b = await api('/api/bootstrap'); state.stats = b.stats; state.cats = b.categories; state.rules = b.rules; stats = b.stats; }

  view.innerHTML = `
  <section class="hero"><div class="container">
    <div class="hero-grid">
      <div>
        <div class="hero-kicker">✦ عضویت آزاد — امانت رایگان</div>
        <h1>سفر به دنیای کتاب‌ها از <span class="hl">کتابخانه سپید</span> آغاز می‌شود</h1>
        <p class="lead">بیش از ${fa(stats.books)} عنوان کتاب در ${fa(state.cats.length)} موضوع گوناگون، از ادبیات کلاسیک تا تازه‌ترین‌های علم و فناوری. عضو شوید و کتاب دلخواهتان را امانت بگیرید.</p>
        <div class="hero-cta">
          <a class="btn btn-gold btn-lg" href="#/books">مرور کتاب‌ها</a>
          ${state.user
            ? '<a class="btn btn-outline btn-lg" href="#/account">پنل من</a>'
            : '<a class="btn btn-outline btn-lg" href="#/register">عضویت در کتابخانه</a>'}
        </div>
      </div>
      <div class="hero-art"><div class="frame"><img src="/img/hero.jpg" alt="سالن مطالعه‌ی کتابخانه سپید"></div></div>
    </div>
    <div class="stats-row">
      <div class="stat-card"><div class="ic">${I.book}</div><div><div class="num">${fa(stats.books)}</div><div class="lbl">عنوان کتاب</div></div></div>
      <div class="stat-card"><div class="ic">${I.layers}</div><div><div class="num">${fa(stats.copies)}</div><div class="lbl">نسخه‌ی فیزیکی</div></div></div>
      <div class="stat-card"><div class="ic">${I.users}</div><div><div class="num">${fa(stats.members)}</div><div class="lbl">عضو فعال</div></div></div>
      <div class="stat-card"><div class="ic">${I.bookmark}</div><div><div class="num">${fa(stats.activeLoans)}</div><div class="lbl">امانت در جریان</div></div></div>
    </div>
  </div></section>

  <section class="section"><div class="container">
    <div class="section-head">
      <div class="section-title"><h2>تازه‌های کتابخانه</h2><div class="rule"></div></div>
      <a class="more" href="#/books">مشاهده‌ی همه ←</a>
    </div>
    <div class="books-grid" id="home-latest">${loading()}</div>
  </div></section>

  <section class="section" style="background:linear-gradient(180deg,transparent,rgba(193,154,75,.08),transparent)"><div class="container">
    <div class="section-head"><div class="section-title"><h2>موضوعات کتاب‌ها</h2><div class="rule"></div></div></div>
    <div class="cats-row">
      ${state.cats.map(c => `<a class="cat-card" href="#/books?cat=${c.id}">
        <span class="dot" style="background:${c.color}"></span>
        <div><div class="n">${esc(c.name)}</div><div class="c">${fa(c.count)} کتاب</div></div>
      </a>`).join('')}
    </div>
  </div></section>

  <section class="section"><div class="container">
    <div class="hero-grid" style="align-items:center">
      <div class="hero-art" style="max-width:420px"><div class="frame" style="transform:rotate(1.2deg)"><img src="/img/reading.jpg" alt="نوار خواندن کتابخانه"></div></div>
      <div>
        <div class="section-title"><h2>قواعد ساده‌ی امانت</h2><div class="rule"></div></div>
        <p class="muted" style="margin-bottom:18px">امانت گرفتن کتاب در کتابخانه سپید آسان است؛ کافی است عضو شوید و درخواست خود را ثبت کنید. پس از تأیید مدیر، کتاب از میز امانت تحویل داده می‌شود.</p>
        <ul style="list-style:none;display:grid;gap:12px">
          <li>🗓️ مهلت هر امانت <b>${fa(state.rules.loanDays)} روز</b> است و تا <b>${fa(state.rules.maxActive)} کتاب</b> همزمان می‌توانید نزد خود داشته باشید.</li>
          <li>💸 برای هر روز تأخیر، جریمه‌ی <b>${money(state.rules.finePerDay)}</b> محاسبه می‌شود.</li>
          <li>🔁 پس از پایان خواندن، از پنل خود «تحویل دادم» را بزنید و کتاب را به میز امانت بیاورید.</li>
        </ul>
      </div>
    </div>
  </div></section>`;

  const latest = await api('/api/books?limit=8&sort=new');
  const grid = $('#home-latest');
  if (grid) grid.innerHTML = latest.items.length
    ? latest.items.map(bookCard).join('')
    : emptyState('هنوز کتابی ثبت نشده است.');

  window.scrollTo(0, 0);
}

/* ================= کاتالوگ کتاب‌ها ================= */
const catalog = { q: '', cat: 'all', sort: 'new', avail: false, page: 1 };

async function viewBooks(view, q) {
  document.title = 'کاتالوگ کتاب‌ها — کتابخانه سپید';
  catalog.q = q.get('q') || '';
  catalog.cat = q.get('cat') || 'all';
  catalog.sort = q.get('sort') || 'new';
  catalog.avail = q.get('avail') === '1';
  catalog.page = Math.max(1, parseInt(q.get('page') || '1', 10) || 1);
  if (!state.cats.length) { const b = await api('/api/bootstrap'); state.cats = b.categories; }

  view.innerHTML = `<div class="container" style="padding-top:38px;padding-bottom:60px">
    <div class="section-title"><h2>کاتالوگ کتاب‌ها</h2><div class="rule"></div></div>

    <div class="toolbar">
      <div class="search-wrap"><span class="ic">${I.search}</span>
        <input class="input" id="cat-q" placeholder="جست‌وجو در عنوان، نویسنده، مترجم…" value="${esc(catalog.q)}">
      </div>
      <select class="input" id="cat-cat">
        <option value="all">همه‌ی موضوعات</option>
        ${state.cats.map(c => `<option value="${c.id}" ${String(catalog.cat) === String(c.id) ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}
      </select>
      <select class="input" id="cat-sort">
        <option value="new" ${catalog.sort === 'new' ? 'selected' : ''}>جدیدترین</option>
        <option value="popular" ${catalog.sort === 'popular' ? 'selected' : ''}>پرامانت‌ترین</option>
        <option value="title" ${catalog.sort === 'title' ? 'selected' : ''}>عنوان (الفبا)</option>
        <option value="author" ${catalog.sort === 'author' ? 'selected' : ''}>نویسنده (الفبا)</option>
      </select>
      <button class="btn ${catalog.avail ? 'btn-primary' : 'btn-outline'}" id="cat-avail">${catalog.avail ? 'فقط موجودها ✓' : 'همه‌ی کتاب‌ها'}</button>
    </div>

    <div class="chips" id="cat-chips">
      <button class="chip ${catalog.cat === 'all' ? 'on' : ''}" data-cat="all">همه</button>
      ${state.cats.map(c => `<button class="chip ${String(catalog.cat) === String(c.id) ? 'on' : ''}" data-cat="${c.id}">
        <span class="dot" style="display:inline-block;width:9px;height:9px;border-radius:3px;background:${c.color};margin-inline-end:6px"></span>${esc(c.name)}
      </button>`).join('')}
    </div>

    <div class="books-grid" id="cat-grid">${loading()}</div>
    <div class="pager" id="cat-pager"></div>
  </div>`;

  const refresh = async () => {
    const gridEl = $('#cat-grid');
    if (!gridEl) return;
    gridEl.innerHTML = loading();
    const p = new URLSearchParams({
      q: catalog.q, cat: catalog.cat, sort: catalog.sort, page: catalog.page,
      ...(catalog.avail ? { available: '1' } : {}),
    });
    const res = await api('/api/books?' + p.toString());
    gridEl.innerHTML = res.items.length
      ? res.items.map(bookCard).join('')
      : emptyState('کتابی با این مشخصات پیدا نشد.', '🔍');
    const pager = $('#cat-pager');
    if (pager) {
      pager.innerHTML = res.pages > 1 ? `
        <button class="btn btn-soft btn-sm" data-pg="${catalog.page - 1}" ${catalog.page <= 1 ? 'disabled' : ''}>قبلی</button>
        <span class="muted small">صفحه‌ی ${fa(res.page)} از ${fa(res.pages)}</span>
        <button class="btn btn-soft btn-sm" data-pg="${catalog.page + 1}" ${catalog.page >= res.pages ? 'disabled' : ''}>بعدی</button>` : '';
      $$('[data-pg]', pager).forEach(b => b.addEventListener('click', () => {
        catalog.page = parseInt(b.dataset.pg, 10); syncHash(); refresh();
      }));
    }
  };
  const syncHash = () => {
    const p = new URLSearchParams();
    if (catalog.q) p.set('q', catalog.q);
    if (catalog.cat !== 'all') p.set('cat', catalog.cat);
    if (catalog.sort !== 'new') p.set('sort', catalog.sort);
    if (catalog.avail) p.set('avail', '1');
    if (catalog.page > 1) p.set('page', catalog.page);
    history.replaceState(null, '', '#/books' + (p.toString() ? '?' + p.toString() : ''));
  };

  $('#cat-q').addEventListener('input', debounce(e => { catalog.q = e.target.value; catalog.page = 1; syncHash(); refresh(); }, 350));
  $('#cat-cat').addEventListener('change', e => { catalog.cat = e.target.value; catalog.page = 1; syncHash(); updateChips(); refresh(); });
  $('#cat-sort').addEventListener('change', e => { catalog.sort = e.target.value; catalog.page = 1; syncHash(); refresh(); });
  $('#cat-avail').addEventListener('click', () => {
    catalog.avail = !catalog.avail; catalog.page = 1; syncHash();
    const btn = $('#cat-avail');
    btn.className = 'btn ' + (catalog.avail ? 'btn-primary' : 'btn-outline');
    btn.textContent = catalog.avail ? 'فقط موجودها ✓' : 'همه‌ی کتاب‌ها';
    refresh();
  });
  function updateChips() {
    $$('#cat-chips .chip').forEach(ch => ch.classList.toggle('on', String(ch.dataset.cat) === String(catalog.cat)));
  }
  $$('#cat-chips .chip').forEach(ch => ch.addEventListener('click', () => {
    catalog.cat = ch.dataset.cat; catalog.page = 1; syncHash(); updateChips();
    $('#cat-cat').value = catalog.cat === 'all' ? 'all' : catalog.cat;
    refresh();
  }));

  await refresh();
  window.scrollTo(0, 0);
}

/* ================= صفحه‌ی کتاب ================= */
async function viewBook(view, id) {
  view.innerHTML = loading();
  const { book, mine, related } = await api('/api/books/' + encodeURIComponent(id));
  document.title = book.title + ' — کتابخانه سپید';

  const u = state.user;
  let actionHtml;
  if (!u) {
    actionHtml = `<a class="btn btn-primary btn-block" href="#/login?next=/book/${book.id}">برای امانت گرفتن، وارد شوید</a>`;
  } else if (u.role === 'admin') {
    actionHtml = `<div class="notice" style="margin:0">مدیر عزیز، مدیریت امانت‌ها از <a href="#/admin/loans" style="font-weight:700">پنل مدیریت</a> انجام می‌شود.</div>`;
  } else if (mine) {
    actionHtml = `<div class="notice" style="margin:0">${mine.status === 'pending' ? 'درخواست امانت شما برای این کتاب در انتظار تأیید مدیر است.' : 'این کتاب هم‌اکنون نزد شماست. زمان تحویل از پنل من.'}</div>
      <a class="btn btn-soft btn-block" style="margin-top:10px" href="#/account">مشاهده‌ی پنل من</a>`;
  } else if (!book.available) {
    actionHtml = `<button class="btn btn-primary btn-block" disabled>فعلاً نسخه‌ی موجودی نیست</button>
      <p class="small muted center" style="margin-top:8px">پس از بازگشت نسخه‌ها دوباره در دسترس می‌شود.</p>`;
  } else {
    actionHtml = `<button class="btn btn-primary btn-block" data-act="borrow" data-id="${book.id}">درخواست امانت این کتاب</button>
      <p class="small muted center" style="margin-top:8px">مهلت ${fa(state.rules.loanDays)} روزه — رایگان برای اعضا</p>`;
  }

  view.innerHTML = `<div class="container">
    <nav class="small muted" style="padding-top:22px"><a href="#/">خانه</a> › <a href="#/books">کتاب‌ها</a>${book.category ? ` › <a href="#/books?cat=${book.category.id}">${esc(book.category.name)}</a>` : ''} › <span style="color:var(--ink-soft)">${esc(book.title)}</span></nav>
    <div class="book-page">
      <div class="side">
        ${coverHTML(book, 'cover-lg')}
        <div>${actionHtml}</div>
        <div class="meta-list">
          <div class="row"><span class="k">وضعیت</span><span class="v"><span class="badge ${book.available ? 'badge-ok' : 'badge-out'}">${book.available ? 'موجود (' + fa(book.availableCopies) + ' نسخه)' : 'امانت‌رفته'}</span></span></div>
          <div class="row"><span class="k">قفسه</span><span class="v">${esc(book.shelf || '—')}</span></div>
          <div class="row"><span class="k">کل نسخه‌ها</span><span class="v">${fa(book.totalCopies)}</span></div>
          <div class="row"><span class="k">دفعات امانت</span><span class="v">${fa(book.borrowCount)} بار</span></div>
        </div>
      </div>
      <div>
        ${book.category ? `<a class="cat-pill" style="background:${book.category.color}" href="#/books?cat=${book.category.id}">${esc(book.category.name)}</a>` : ''}
        <h1>${esc(book.title)}</h1>
        <div class="muted" style="font-size:1.05rem">${esc(book.author)}${book.translator ? ` — ترجمه‌ی ${esc(book.translator)}` : ''}</div>
        <p class="desc">${esc(book.description) || 'توضیحی برای این کتاب ثبت نشده است.'}</p>
        <div class="meta-list">
          <div class="row"><span class="k">نویسنده</span><span class="v">${esc(book.author)}</span></div>
          <div class="row"><span class="k">مترجم</span><span class="v">${esc(book.translator || '—')}</span></div>
          <div class="row"><span class="k">ناشر</span><span class="v">${esc(book.publisher || '—')}</span></div>
          <div class="row"><span class="k">سال انتشار</span><span class="v">${book.pubYear ? fa(book.pubYear) : '—'}</span></div>
          <div class="row"><span class="k">شابک</span><span class="v" style="direction:ltr">${esc(book.isbn || '—')}</span></div>
        </div>
      </div>
    </div>
    ${related.length ? `
    <section class="section">
      <div class="section-title"><h2>کتاب‌های مرتبط</h2><div class="rule"></div></div>
      <div class="books-grid">${related.map(bookCard).join('')}</div>
    </section>` : ''}
  </div>`;
  window.scrollTo(0, 0);
}

/* ================= ورود و عضویت ================= */
function viewLogin(view, q) {
  document.title = 'ورود — کتابخانه سپید';
  const next = q.get('next') || (state.user ? (state.user.role === 'admin' ? '/admin' : '/account') : '/');
  view.innerHTML = `<div class="auth-wrap">
    <div class="auth-card">
      <h1>ورود به حساب</h1>
      <p class="sub">به کتابخانه سپید خوش آمدید؛ دوباره سفرتان را ادامه دهید.</p>
      <div class="form-error" id="login-err"></div>
      <form data-form="login" data-next="${esc(next)}">
        <div class="field"><label>ایمیل</label><input class="input" name="email" type="email" required placeholder="you@example.com" style="direction:ltr;text-align:left"></div>
        <div class="field"><label>رمز عبور</label><input class="input" name="password" type="password" required placeholder="••••••••"></div>
        <button class="btn btn-primary btn-block btn-lg" type="submit">ورود</button>
      </form>
      <div class="auth-alt">حساب ندارید؟ <a href="#/register">عضویت در کتابخانه</a></div>
      <div class="hint-box">
        <b>حساب‌های آزمایشی:</b><br>
        👑 مدیر: <span style="direction:ltr;display:inline-block">admin@ketabkhooneh.ir</span> / admin1234<br>
        🙋 عضو: <span style="direction:ltr;display:inline-block">member@ketabkhooneh.ir</span> / member1234
      </div>
    </div>
  </div>`;
  window.scrollTo(0, 0);
}

function viewRegister(view, q) {
  document.title = 'عضویت — کتابخانه سپید';
  const next = q.get('next') || '/account';
  view.innerHTML = `<div class="auth-wrap">
    <div class="auth-card">
      <h1>عضویت در کتابخانه</h1>
      <p class="sub">چند ثانیه وقت بگذارید و عضو خانواده‌ی بزرگ کتاب‌خوان‌ها شوید.</p>
      <div class="form-error" id="reg-err"></div>
      <form data-form="register" data-next="${esc(next)}">
        <div class="field"><label>نام و نام خانوادگی <span class="req">*</span></label><input class="input" name="fullName" required placeholder="مثلاً: سارا محمدی"></div>
        <div class="field"><label>ایمیل <span class="req">*</span></label><input class="input" name="email" type="email" required placeholder="you@example.com" style="direction:ltr;text-align:left"></div>
        <div class="field"><label>تلفن (اختیاری)</label><input class="input" name="phone" placeholder="۰۹۱۲۰۰۰۰۰۰۰"></div>
        <div class="field"><label>رمز عبور <span class="req">*</span></label><input class="input" name="password" type="password" required minlength="6" placeholder="حداقل ۶ کاراکتر"></div>
        <div class="field"><label>تکرار رمز عبور <span class="req">*</span></label><input class="input" name="password2" type="password" required placeholder="تکرار رمز"></div>
        <button class="btn btn-primary btn-block btn-lg" type="submit">ثبت عضویت</button>
      </form>
      <div class="auth-alt">قبلاً عضو شده‌اید؟ <a href="#/login">وارد شوید</a></div>
    </div>
  </div>`;
  window.scrollTo(0, 0);
}

/* ================= پنل عضو ================= */
function loanItem(l, opts = {}) {
  const b = l.book || {};
  let side = statusBadge(l.status);
  if (!opts.readonly) {
    if (l.status === 'active') side += `<button class="btn btn-sm btn-outline" data-act="give-back" data-id="${l.id}">تحویل دادم</button>`;
    if (l.status === 'active' || l.status === 'return_requested') {
      side += l.dueTag || '';
    }
  } else if (l.dueTag) side += l.dueTag;
  return `<div class="loan-item">
    ${b.category || b.title ? miniCover(b, b.title ? b.title.charAt(0) : '؟') : ''}
    <div class="li-main">
      <div class="li-title"><a href="#/book/${b.id}">${esc(b.title || '—')}</a></div>
      <div class="li-sub">${esc(b.author || '')} · درخواست: ${fmtDateShort(l.requestedAt)}${l.borrowedAt ? ' · امانت: ' + fmtDateShort(l.borrowedAt) : ''}${l.dueAt ? ' · موعد: ' + fmtDateShort(l.dueAt) : ''}${l.returnedAt ? ' · بازگشت: ' + fmtDateShort(l.returnedAt) : ''}</div>
    </div>
    <div class="li-side">${side}</div>
  </div>`;
}
function dueTagFor(l) {
  if (l.overdue) return `<span class="due-tag due-late">${fa(Math.abs(l.daysLeft))} روز تأخیر — جریمه ${money(l.fine)}</span>`;
  if (l.daysLeft !== null && l.daysLeft <= 3) return `<span class="due-tag due-soon">${fa(l.daysLeft)} روز مانده</span>`;
  if (l.daysLeft !== null) return `<span class="due-tag due-ok">${fa(l.daysLeft)} روز مانده</span>`;
  return '';
}

async function viewAccount(view) {
  if (!state.user) return nav('/login?next=/account');
  if (state.user.role === 'admin') return nav('/admin');
  document.title = 'پنل من — کتابخانه سپید';
  view.innerHTML = loading();
  const data = await api('/api/me/loans');
  const loans = data.loans.map(l => ({ ...l, dueTag: dueTagFor(l) }));
  const pending = loans.filter(l => l.status === 'pending');
  const active = loans.filter(l => l.status === 'active' || l.status === 'return_requested');
  const history = loans.filter(l => l.status === 'returned' || l.status === 'rejected');
  const overdueCount = loans.filter(l => l.overdue).length;

  const u = state.user;
  view.innerHTML = `<div class="container">
    <div class="section-title" style="padding-top:38px"><h2>پنل عضو</h2><div class="rule"></div></div>
    <div class="account-grid">
      <div class="card card-pad profile-card">
        <div class="avatar-xl">${esc(u.fullName.trim().charAt(0))}</div>
        <h3 style="margin-bottom:4px">${esc(u.fullName)}</h3>
        <div class="muted small" style="margin-bottom:14px">${esc(u.email)}</div>
        <div class="code-box">${esc(u.membershipCode)}</div>
        <div class="muted small" style="margin-top:12px">عضو از ${fmtDate(u.createdAt)}</div>
        ${u.phone ? `<div class="muted small">تلفن: ${esc(u.phone)}</div>` : ''}
        <div class="meta-list" style="margin-top:18px;text-align:right">
          <div class="row"><span class="k">امانت فعال</span><span class="v">${fa(active.length)} از ${fa(data.maxActive)}</span></div>
          <div class="row"><span class="k">در انتظار تأیید</span><span class="v">${fa(pending.length)}</span></div>
          <div class="row"><span class="k">کتاب‌های دارای تأخیر</span><span class="v" style="${overdueCount ? 'color:var(--accent)' : ''}">${fa(overdueCount)}</span></div>
        </div>
      </div>
      <div>
        ${overdueCount ? `<div class="notice">⏰ شما ${fa(overdueCount)} کتاب تأخیر دارید. لطفاً برای بازگرداندن اقدام کنید تا جریمه بیشتر نشود.</div>` : ''}

        <h3 style="margin-bottom:12px">📖 امانت‌های من ${active.length ? `<span class="muted small">(${fa(active.length)})</span>` : ''}</h3>
        <div class="loan-list" style="margin-bottom:26px">
          ${active.length ? active.map(l => loanItem(l)).join('') : emptyState('فعلاً کتابی نزد شما نیست.', '📖')}
        </div>

        <h3 style="margin-bottom:12px">⏳ درخواست‌های در انتظار تأیید ${pending.length ? `<span class="muted small">(${fa(pending.length)})</span>` : ''}</h3>
        <div class="loan-list" style="margin-bottom:26px">
          ${pending.length ? pending.map(l => loanItem(l)).join('') : emptyState('درخواستی در انتظار نیست.', '⏳')}
        </div>

        <h3 style="margin-bottom:12px">🗂️ تاریخچه‌ی امانت‌ها</h3>
        <div class="loan-list">
          ${history.length ? history.map(l => loanItem(l, { readonly: true })).join('') : emptyState('هنوز تاریخی ثبت نشده است.', '🗂️')}
        </div>
      </div>
    </div>
  </div>`;
  window.scrollTo(0, 0);
}

/* ================= پنل مدیریت ================= */
async function viewAdmin(view, tab) {
  if (!state.user) return nav('/login?next=/admin');
  if (state.user.role !== 'admin') {
    view.innerHTML = `<div class="container"><div class="empty" style="padding:80px 20px"><div class="big">🔒</div>این بخش فقط برای مدیر کتابخانه است.</div></div>`;
    return;
  }
  document.title = 'پنل مدیریت — کتابخانه سپید';
  // شمارش درخواست‌های در انتظار برای نشان ناوبری
  try {
    const s = await api('/api/admin/stats');
    state.pendingCount = s.pendingLoans;
  } catch { /* بی‌اهمیت */ }

  view.innerHTML = `<div class="container">
    <div class="admin-layout">
      <aside class="admin-side">
        <div class="head"><div class="t">پنل مدیریت</div><div class="s">کتابخانه سپید</div></div>
        <nav class="admin-nav">
          <a href="#/admin" class="${tab === 'dash' ? 'active' : ''}">📊 داشبورد</a>
          <a href="#/admin/books" class="${tab === 'books' ? 'active' : ''}">📚 کتاب‌ها</a>
          <a href="#/admin/loans" class="${tab === 'loans' ? 'active' : ''}">🔄 امانت‌ها ${state.pendingCount ? `<span class="cnt">${fa(state.pendingCount)}</span>` : ''}</a>
          <a href="#/admin/members" class="${tab === 'members' ? 'active' : ''}">🙋 اعضا</a>
          <a href="#/admin/categories" class="${tab === 'categories' ? 'active' : ''}">🏷️ دسته‌بندی‌ها</a>
        </nav>
      </aside>
      <div class="admin-content" id="admin-content"></div>
    </div>
  </div>`;

  const c = $('#admin-content');
  if (tab === 'books') await adminBooks(c);
  else if (tab === 'loans') await adminLoans(c);
  else if (tab === 'members') await adminMembers(c);
  else if (tab === 'categories') await adminCategories(c);
  else await adminDash(c);
  window.scrollTo(0, 0);
}

/* ---------- داشبورد ---------- */
async function adminDash(c) {
  const s = await api('/api/admin/stats');
  c.innerHTML = `
    <h1>داشبورد</h1>
    <div class="admin-stats">
      <div class="a-stat"><div class="n">${fa(s.books)}</div><div class="l">عنوان کتاب</div></div>
      <div class="a-stat"><div class="n">${fa(s.copies)}</div><div class="l">کل نسخه‌ها</div></div>
      <div class="a-stat"><div class="n">${fa(s.members)}</div><div class="l">عضو کتابخانه</div></div>
      <div class="a-stat"><div class="n">${fa(s.activeLoans)}</div><div class="l">امانت فعال</div></div>
      <div class="a-stat ${s.pendingLoans ? 'warn' : ''}"><div class="n">${fa(s.pendingLoans)}</div><div class="l">درخواست در انتظار</div></div>
      <div class="a-stat ${s.overdueLoans ? 'warn' : ''}"><div class="n">${fa(s.overdueLoans)}</div><div class="l">امانت معوق</div></div>
      <div class="a-stat"><div class="n">${fa(s.returnedLoans)}</div><div class="l">امانت کامل‌شده</div></div>
    </div>
    ${s.pendingLoans ? `<div class="notice">⏳ ${fa(s.pendingLoans)} درخواست امانت در انتظار تأیید شماست. <a href="#/admin/loans" style="font-weight:700;color:var(--accent)">بررسی کن ←</a></div>` : ''}
    <div class="admin-cols">
      <div>
        <h3 style="margin-bottom:12px;font-size:1.05rem">آخرین رویدادها</h3>
        <div class="loan-list">
          ${s.recent.length ? s.recent.map(l => `
            <div class="loan-item">
              ${l.book ? miniCover(l.book, l.book.title.charAt(0)) : ''}
              <div class="li-main">
                <div class="li-title">${esc(l.book ? l.book.title : '—')}</div>
                <div class="li-sub">${esc(l.user ? l.user.fullName : '')} · ${LOAN_FA[l.status]}${l.dueAt ? ' · موعد ' + fmtDateShort(l.dueAt) : ''}</div>
              </div>
              <div class="li-side">${statusBadge(l.status)}
                ${l.status === 'pending' ? `<button class="btn btn-sm btn-primary" data-act="loan-approve" data-id="${l.id}">تأیید</button><button class="btn btn-sm btn-danger" data-act="loan-reject" data-id="${l.id}">رد</button>` : ''}
              </div>
            </div>`).join('') : emptyState('رویدادی ثبت نشده است.')}
        </div>
      </div>
      <div>
        <h3 style="margin-bottom:12px;font-size:1.05rem">محبوب‌ترین کتاب‌ها</h3>
        <div class="loan-list">
          ${s.topBooks.map((b, i) => `
            <div class="loan-item">
              ${miniCover(b, b.title.charAt(0))}
              <div class="li-main">
                <div class="li-title"><a href="#/book/${b.id}">${esc(b.title)}</a></div>
                <div class="li-sub">${esc(b.author)}</div>
              </div>
              <div class="li-side"><span class="badge badge-ok">${fa(b.borrowCount)} بار امانت</span></div>
            </div>`).join('')}
        </div>
      </div>
    </div>`;
}

/* ---------- کتاب‌ها ---------- */
async function adminBooks(c) {
  c.innerHTML = `<h1>مدیریت کتاب‌ها</h1>
    <div class="toolbar" style="grid-template-columns:1fr auto auto">
      <div class="search-wrap"><span class="ic">${I.search}</span><input class="input" id="ab-q" placeholder="جست‌وجوی عنوان، نویسنده یا شابک…"></div>
      <button class="btn btn-soft" id="ab-export">خروجی CSV</button>
      <button class="btn btn-primary" data-act="book-new">${I.plus} کتاب جدید</button>
    </div>
    <div id="ab-list">${loading()}</div>`;

  const refresh = async () => {
    const res = await api('/api/admin/books?q=' + encodeURIComponent($('#ab-q') ? $('#ab-q').value : ''));
    $('#ab-list').innerHTML = res.items.length ? `
    <div class="table-wrap"><table class="tbl">
      <thead><tr><th>کتاب</th><th>نویسنده</th><th>دسته</th><th>نسخه‌ها</th><th>قفسه</th><th>امانت</th><th>عملیات</th></tr></thead>
      <tbody>${res.items.map(b => `
        <tr>
          <td><a class="bcell" href="#/book/${b.id}">${miniCover(b, b.title.charAt(0))}<span>${esc(b.title)}</span></a></td>
          <td>${esc(b.author)}</td>
          <td>${b.category ? `<span class="badge" style="background:${b.category.color}22;color:${shade(b.category.color, -25)}">● ${esc(b.category.name)}</span>` : '—'}</td>
          <td>${fa(b.availableCopies)} / ${fa(b.totalCopies)}</td>
          <td>${esc(b.shelf || '—')}</td>
          <td>${fa(b.borrowCount)} بار</td>
          <td><div class="ops">
            <button class="btn btn-sm btn-soft" data-act="book-edit" data-id="${b.id}">${I.edit} ویرایش</button>
            <button class="btn btn-sm btn-danger" data-act="book-del" data-id="${b.id}" data-title="${esc(b.title)}">${I.trash} حذف</button>
          </div></td>
        </tr>`).join('')}</tbody>
    </table></div>` : emptyState('کتابی پیدا نشد.');

    $('#ab-export').onclick = () => {
      const rows = [['عنوان', 'نویسنده', 'مترجم', 'ناشر', 'دسته', 'کل', 'موجود', 'قفسه']];
      res.items.forEach(b => rows.push([b.title, b.author, b.translator, b.publisher, b.category ? b.category.name : '', b.totalCopies, b.availableCopies, b.shelf]));
      const csv = '\uFEFF' + rows.map(r => r.map(x => '"' + String(x).replace(/"/g, '""') + '"').join(',')).join('\n');
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
      a.download = 'books.csv'; a.click();
    };
  };
  $('#ab-q').addEventListener('input', debounce(refresh, 300));
  await refresh();
}

function bookModal(book) {
  const cats = state.cats;
  const b = book || { title: '', author: '', translator: '', publisher: '', pubYear: '', isbn: '', category: null, totalCopies: 1, shelf: '', description: '' };
  const selectedCat = b.category ? b.category.id : '';
  openModal(`
    <h2>${book ? 'ویرایش کتاب' : 'افزودن کتاب جدید'}</h2>
    <form data-form="book-save" data-id="${book ? book.id : ''}">
      <div class="form-row">
        <div class="field"><label>عنوان <span class="req">*</span></label><input class="input" name="title" required value="${esc(b.title)}"></div>
        <div class="field"><label>نویسنده <span class="req">*</span></label><input class="input" name="author" required value="${esc(b.author)}"></div>
      </div>
      <div class="form-row">
        <div class="field"><label>مترجم</label><input class="input" name="translator" value="${esc(b.translator)}"></div>
        <div class="field"><label>ناشر</label><input class="input" name="publisher" value="${esc(b.publisher)}"></div>
      </div>
      <div class="form-row">
        <div class="field"><label>سال انتشار</label><input class="input" name="pubYear" type="number" min="1200" max="1500" value="${b.pubYear || ''}" placeholder="مثلاً ۱۴۰۲"></div>
        <div class="field"><label>شابک</label><input class="input" name="isbn" value="${esc(b.isbn)}" style="direction:ltr;text-align:left"></div>
      </div>
      <div class="form-row">
        <div class="field"><label>دسته‌بندی <span class="req">*</span></label>
          <select class="input" name="categoryId" id="bm-cat">
            ${cats.map(x => `<option value="${x.id}" ${String(selectedCat) === String(x.id) ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}
            <option value="__new">➕ دسته‌ی جدید…</option>
          </select>
        </div>
        <div class="field"><label>تعداد نسخه <span class="req">*</span></label><input class="input" name="totalCopies" type="number" min="1" max="999" required value="${book && book.totalCopies ? book.totalCopies : 1}" inputmode="numeric"></div>
      </div>
      <div class="field" id="bm-newcat" style="display:none">
        <label>نام دسته‌ی جدید</label>
        <div style="display:flex;gap:10px">
          <input class="input" name="newCategoryName" placeholder="مثلاً: هنر و معماری">
          <input class="input" name="newCategoryColor" type="color" value="#8a6d4f" style="width:64px;padding:4px;height:auto">
        </div>
      </div>
      <div class="form-row">
        <div class="field"><label>قفسه</label><input class="input" name="shelf" value="${esc(b.shelf)}" placeholder="مثلاً A2-5"></div>
      </div>
      <div class="field"><label>توضیح</label><textarea class="input" name="description" rows="3">${esc(b.description)}</textarea></div>
      <button class="btn btn-primary btn-block" type="submit">${book ? 'ذخیره‌ی تغییرات' : 'افزودن کتاب'}</button>
    </form>`, true);
  $('#bm-cat').addEventListener('change', e => { $('#bm-newcat').style.display = e.target.value === '__new' ? 'block' : 'none'; });
}

/* ---------- امانت‌ها ---------- */
async function adminLoans(c) {
  const chips = [
    ['all', 'همه'], ['pending', 'در انتظار تأیید'], ['active', 'امانت فعال'],
    ['return_requested', 'درخواست بازگشت'], ['returned', 'بازگشته'], ['rejected', 'رد شده'],
  ];
  c.innerHTML = `<h1>مدیریت امانت‌ها</h1>
    <div class="chips" id="al-chips">
      ${chips.map(([v, t]) => `<button class="chip" data-st="${v}">${t}</button>`).join('')}
    </div>
    <div id="al-list">${loading()}</div>`;
  let cur = 'all';

  const refresh = async () => {
    const res = await api('/api/admin/loans?status=' + cur);
    $$('#al-chips .chip').forEach(ch => ch.classList.toggle('on', ch.dataset.st === cur));
    $('#al-list').innerHTML = res.items.length ? `
    <div class="table-wrap"><table class="tbl">
      <thead><tr><th>عضو</th><th>کتاب</th><th>وضعیت</th><th>درخواست</th><th>امانت</th><th>موعد</th><th>عملیات</th></tr></thead>
      <tbody>${res.items.map(l => `
        <tr>
          <td><b>${esc(l.user ? l.user.fullName : '—')}</b><div class="small muted">${esc(l.user ? l.user.membershipCode : '')}</div></td>
          <td><a class="bcell" href="#/book/${l.book ? l.book.id : ''}">${l.book ? miniCover(l.book, l.book.title.charAt(0)) : ''}<span>${esc(l.book ? l.book.title : '—')}</span></a></td>
          <td>${statusBadge(l.status)}${l.overdue && (l.status === 'active' || l.status === 'return_requested') ? `<div class="small" style="color:var(--accent);font-weight:700;margin-top:4px">${fa(Math.abs(l.daysLeft))} روز تأخیر · ${money(l.fine)}</div>` : ''}</td>
          <td class="small">${fmtDateShort(l.requestedAt)}</td>
          <td class="small">${fmtDateShort(l.borrowedAt)}</td>
          <td class="small">${fmtDateShort(l.dueAt)}</td>
          <td><div class="ops">
            ${l.status === 'pending' ? `<button class="btn btn-sm btn-primary" data-act="loan-approve" data-id="${l.id}">${I.check} تأیید</button><button class="btn btn-sm btn-danger" data-act="loan-reject" data-id="${l.id}">رد</button>` : ''}
            ${l.status === 'active' || l.status === 'return_requested' ? `<button class="btn btn-sm btn-soft" data-act="loan-return" data-id="${l.id}">ثبت بازگشت</button>` : ''}
            ${(l.status === 'returned' || l.status === 'rejected') ? '<span class="muted small">—</span>' : ''}
          </div></td>
        </tr>`).join('')}</tbody>
    </table></div>` : emptyState('امانتی در این وضعیت نیست.');
  };
  $$('#al-chips .chip').forEach(ch => ch.addEventListener('click', () => { cur = ch.dataset.st; refresh(); }));
  await refresh();
}

/* ---------- اعضا ---------- */
async function adminMembers(c) {
  c.innerHTML = `<h1>اعضای کتابخانه</h1>
    <div class="toolbar" style="grid-template-columns:1fr">
      <div class="search-wrap"><span class="ic">${I.search}</span><input class="input" id="am-q" placeholder="جست‌وجوی نام، ایمیل یا کد عضویت…"></div>
    </div>
    <div id="am-list">${loading()}</div>`;

  const refresh = async () => {
    const res = await api('/api/admin/members?q=' + encodeURIComponent($('#am-q') ? $('#am-q').value : ''));
    $('#am-list').innerHTML = res.items.length ? `
    <div class="table-wrap"><table class="tbl">
      <thead><tr><th>نام</th><th>ایمیل</th><th>کد عضویت</th><th>نقش</th><th>امانت فعال</th><th>مجموع امانت</th><th>عضویت</th><th></th></tr></thead>
      <tbody>${res.items.map(m => `
        <tr>
          <td><div class="bcell"><span class="avatar" style="background:${m.role === 'admin' ? 'var(--accent)' : 'var(--gold)'}">${esc(m.fullName.charAt(0))}</span><span>${esc(m.fullName)}</span></div></td>
          <td style="direction:ltr;text-align:left" class="small">${esc(m.email)}</td>
          <td>${esc(m.membershipCode)}</td>
          <td>${m.role === 'admin' ? '<span class="badge badge-active">مدیر</span>' : '<span class="badge badge-ok">عضو</span>'}</td>
          <td>${fa(m.activeLoans)}</td>
          <td>${fa(m.totalLoans)}</td>
          <td class="small">${fmtDateShort(m.createdAt)}</td>
          <td><button class="btn btn-sm btn-soft" data-act="member-view" data-id="${m.id}">${I.eye} پرونده</button></td>
        </tr>`).join('')}</tbody>
    </table></div>` : emptyState('عضوی پیدا نشد.');
  };
  $('#am-q').addEventListener('input', debounce(refresh, 300));
  await refresh();
}

async function memberModal(id) {
  const res = await api('/api/admin/members/' + id + '/loans');
  const m = res.member;
  const loans = res.loans.map(l => ({ ...l, dueTag: dueTagFor(l) }));
  openModal(`
    <h2>پرونده‌ی عضو</h2>
    <div style="display:flex;align-items:center;gap:14px;margin-bottom:8px">
      <span class="avatar" style="width:52px;height:52px;font-size:1.4rem;background:var(--gold);color:#33230e">${esc(m.fullName.charAt(0))}</span>
      <div>
        <div style="font-weight:900;font-size:1.1rem">${esc(m.fullName)} ${m.role === 'admin' ? '<span class="badge badge-active">مدیر</span>' : ''}</div>
        <div class="muted small" style="direction:ltr;text-align:right">${esc(m.email)} · ${esc(m.membershipCode)}</div>
      </div>
    </div>
    <h3 style="font-size:.95rem;margin:18px 0 10px">امانت‌ها (${fa(loans.length)})</h3>
    <div class="loan-list">
      ${loans.length ? loans.map(l => loanItem(l, { readonly: true })).join('') : emptyState('این عضو هنوز امانتی نداشته است.')}
    </div>`, true);
}

/* ---------- دسته‌بندی‌ها ---------- */
async function adminCategories(c) {
  const res = await api('/api/bootstrap');
  state.cats = res.categories;
  c.innerHTML = `<h1>دسته‌بندی‌ها</h1>
    <form data-form="cat-add" class="card card-pad" style="display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap;margin-bottom:22px">
      <div class="field" style="flex:1;min-width:200px;margin:0"><label>نام دسته‌ی جدید</label><input class="input" name="name" required placeholder="مثلاً: هنر و معماری"></div>
      <div class="field" style="margin:0"><label>رنگ</label><input class="input" name="color" type="color" value="#8a6d4f" style="width:64px;padding:4px;height:auto"></div>
      <button class="btn btn-primary" type="submit">${I.plus} افزودن دسته</button>
    </form>
    <div class="cats-row" id="ac-list">
      ${res.categories.map(x => `
        <div class="cat-card">
          <span class="dot" style="background:${x.color}"></span>
          <div style="flex:1"><div class="n">${esc(x.name)}</div><div class="c">${fa(x.count)} کتاب</div></div>
          ${x.count === 0 ? `<button class="btn btn-sm btn-danger" data-act="cat-del" data-id="${x.id}" data-name="${esc(x.name)}">${I.trash}</button>` : ''}
        </div>`).join('')}
    </div>`;
}

/* ================= اکشن‌های سراسری ================= */
const actions = {
  'burger': () => $('#main-nav').classList.toggle('open'),
  'modal-close': () => closeModal(),
  'confirm-yes': async () => { const cb = confirmCb; confirmCb = null; closeModal(); if (cb) await cb(); },

  'logout': async () => {
    await api('/api/auth/logout', { method: 'POST' });
    state.user = null;
    toast('از حساب خود خارج شدید. به امید دیدار!');
    nav('/'); renderHeader();
  },

  'borrow': async el => {
    try {
      const res = await api('/api/me/loans', { method: 'POST', body: { bookId: parseInt(el.dataset.id, 10) } });
      toast(res.message || 'درخواست ثبت شد.');
      renderHeader();
      route();
    } catch (e) { toast(e.message, 'err'); }
  },

  'give-back': el => {
    confirmModal('ثبت درخواست بازگرداندن', 'آیا کتاب را به کتابخانه برمی‌گردانید؟ پس از ثبت، کتاب را به میز امانت تحویل دهید.', async () => {
      try {
        const res = await api('/api/me/loans/' + el.dataset.id + '/return', { method: 'POST' });
        toast(res.message || 'ثبت شد.');
        route();
      } catch (e) { toast(e.message, 'err'); }
    });
  },

  'book-new': () => bookModal(null),
  'book-edit': async el => {
    try {
      const res = await api('/api/books/' + el.dataset.id);
      bookModal(res.book);
    } catch (e) { toast(e.message, 'err'); }
  },
  'book-del': el => {
    const { id, title } = el.dataset;
    confirmModal('حذف کتاب', `آیا از حذف «${title}» مطمئن هستید؟ این کار بازگشت‌پذیر نیست.`, async () => {
      try {
        const res = await api('/api/admin/books/' + id, { method: 'DELETE' });
        toast(res.message || 'حذف شد.');
        route();
      } catch (e) { toast(e.message, 'err'); }
    });
  },

  'loan-approve': async el => {
    try {
      const res = await api('/api/admin/loans/' + el.dataset.id + '/approve', { method: 'POST' });
      toast(res.message || 'تأیید شد.');
      route();
    } catch (e) { toast(e.message, 'err'); }
  },
  'loan-reject': async el => {
    try {
      const res = await api('/api/admin/loans/' + el.dataset.id + '/reject', { method: 'POST' });
      toast(res.message || 'رد شد.');
      route();
    } catch (e) { toast(e.message, 'err'); }
  },
  'loan-return': async el => {
    try {
      const res = await api('/api/admin/loans/' + el.dataset.id + '/return', { method: 'POST' });
      toast(res.message || 'بازگشت ثبت شد.');
      route();
    } catch (e) { toast(e.message, 'err'); }
  },

  'member-view': el => memberModal(el.dataset.id),

  'cat-del': el => {
    const { id, name } = el.dataset;
    confirmModal('حذف دسته', `دسته‌ی «${name}» حذف شود؟`, async () => {
      try {
        const res = await api('/api/admin/categories/' + id, { method: 'DELETE' });
        toast(res.message || 'حذف شد.');
        route();
      } catch (e) { toast(e.message, 'err'); }
    });
  },
};

document.addEventListener('click', async e => {
  const el = e.target.closest('[data-act]');
  if (!el) return;
  const fn = actions[el.dataset.act];
  if (fn) { e.preventDefault(); try { await fn(el, e); } catch (err) { toast(err.message, 'err'); } }
  return;
});
// بستن مودال با کلیک روی پس‌زمینه
document.addEventListener('mousedown', e => { if (e.target.classList && e.target.classList.contains('overlay')) closeModal(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });

/* ---------- فرم‌ها ---------- */
const forms = {
  'login': async f => {
    const err = $('#login-err');
    try {
      const res = await api('/api/auth/login', {
        method: 'POST',
        body: { email: f.email.value, password: f.password.value },
      });
      state.user = res.user;
      toast('خوش آمدید ' + res.user.fullName + '!');
      nav(f.dataset.next || '/');
      renderHeader();
    } catch (e) { err.textContent = e.message; err.classList.add('show'); }
  },
  'register': async f => {
    const err = $('#reg-err');
    if (f.password.value !== f.password2.value) {
      err.textContent = 'رمز عبور و تکرار آن یکسان نیستند.'; err.classList.add('show'); return;
    }
    try {
      const res = await api('/api/auth/register', {
        method: 'POST',
        body: { fullName: f.fullName.value, email: f.email.value, phone: f.phone.value, password: f.password.value },
      });
      state.user = res.user;
      toast(res.message || 'عضویت انجام شد. خوش آمدید!');
      nav(f.dataset.next || '/account');
      renderHeader();
    } catch (e) { err.textContent = e.message; err.classList.add('show'); }
  },
  'book-save': async f => {
    const id = f.dataset.id;
    const body = {
      title: f.title.value, author: f.author.value, translator: f.translator.value,
      publisher: f.publisher.value, pubYear: f.pubYear.value, isbn: f.isbn.value,
      categoryId: f.categoryId.value === '__new' ? null : f.categoryId.value,
      newCategoryName: f.categoryId.value === '__new' ? f.newCategoryName.value : '',
      newCategoryColor: f.categoryId.value === '__new' ? f.newCategoryColor.value : '',
      totalCopies: f.totalCopies.value, shelf: f.shelf.value, description: f.description.value,
    };
    try {
      const res = await api(id ? '/api/admin/books/' + id : '/api/admin/books', {
        method: id ? 'PUT' : 'POST', body,
      });
      toast(res.message || 'ذخیره شد.');
      closeModal();
      const b = await api('/api/bootstrap'); state.cats = b.categories; state.stats = b.stats;
      route();
    } catch (e) { toast(e.message, 'err'); }
  },
  'cat-add': async f => {
    try {
      const res = await api('/api/admin/categories', { method: 'POST', body: { name: f.name.value, color: f.color.value } });
      toast(res.message || 'ساخته شد.');
      route();
    } catch (e) { toast(e.message, 'err'); }
  },
};
document.addEventListener('submit', async e => {
  const f = e.target.closest('form[data-form]');
  if (!f) return;
  e.preventDefault();
  const fn = forms[f.dataset.form];
  if (fn) { try { await fn(f); } catch (err) { toast(err.message, 'err'); } }
});

/* ---------- شروع ---------- */
window.addEventListener('hashchange', route);

(async function boot() {
  try {
    const [me, bootData] = await Promise.all([api('/api/auth/me'), api('/api/bootstrap')]);
    state.user = me.user;
    state.cats = bootData.categories;
    state.stats = bootData.stats;
    state.rules = bootData.rules || state.rules;
  } catch { /* سرور در دسترس نیست */ }
  renderHeader();
  renderFooter();
  route();
})();
