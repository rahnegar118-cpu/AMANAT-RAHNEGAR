'use strict';
/**
 * سرور کتابخانه سپید — Node.js خالص، بدون هیچ وابستگی خارجی
 * اجرا:  node server.js   (یا npm start)
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const { ApiError } = require('./src/api');
const registerApi = require('./src/api');
const { getUser } = require('./src/auth-util');

const PORT = parseInt(process.env.PORT || '3000', 10);
const HOST = '0.0.0.0';
const PUBLIC_DIR = path.join(__dirname, 'public');

/* ---------------- روتر ---------------- */

const routes = [];
function add(method, pattern, handler, guard) {
  const keys = [];
  const rx = new RegExp(
    '^' + pattern.split('/').map(seg => {
      if (seg.startsWith(':')) { keys.push(seg.slice(1)); return '([^/]+)'; }
      return seg.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }).join('/') + '/?$'
  );
  routes.push({ method, rx, keys, handler, guard });
}
registerApi(add);

/* ---------------- ابزارهای HTTP ---------------- */

function sendJSON(res, status, obj, extraHeaders = {}) {
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    ...extraHeaders,
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', c => {
      size += c.length;
      if (size > 200 * 1024) { reject(new ApiError(413, 'درخواست بزرگ‌تر از حد مجاز است.')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); }
      catch { reject(new ApiError(400, 'بدنه‌ی درخواست معتبر نیست.')); }
    });
    req.on('error', () => reject(new ApiError(400, 'خطا در دریافت درخواست.')));
  });
}

/* ---------------- فایل‌های استاتیک ---------------- */

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.woff': 'font/woff',
  '.txt': 'text/plain; charset=utf-8',
};

function serveStatic(req, res, pathname) {
  if (pathname === '/') pathname = '/index.html';
  const filePath = path.normalize(path.join(PUBLIC_DIR, decodeURIComponent(pathname)));

  // جلوگیری از خروج از پوشه‌ی public
  if (!filePath.startsWith(PUBLIC_DIR + path.sep) && filePath !== PUBLIC_DIR) {
    res.writeHead(403); res.end('Forbidden'); return;
  }

  fs.stat(filePath, (err, stat) => {
    let target = filePath;
    if (err || !stat.isFile()) {
      // fallback برای مسیرهای SPA
      if (!path.extname(pathname)) {
        target = path.join(PUBLIC_DIR, 'index.html');
      } else {
        res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('404 — پیدا نشد');
        return;
      }
    }
    const ext = path.extname(target).toLowerCase();
    const mime = MIME[ext] || 'application/octet-stream';
    fs.readFile(target, (err2, buf) => {
      if (err2) { res.writeHead(404); res.end('404'); return; }
      res.writeHead(200, {
        'Content-Type': mime,
        'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=3600',
      });
      res.end(buf);
    });
  });
}

/* ---------------- سرور ---------------- */

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  const pathname = url.pathname;

  try {
    if (pathname.startsWith('/api/')) {
      const match = routes.find(r => r.method === req.method && r.rx.test(pathname));
      if (!match) return sendJSON(res, 404, { error: 'مسیر API پیدا نشد.' });

      const params = {};
      const values = pathname.match(match.rx);
      match.keys.forEach((k, i) => { params[k] = decodeURIComponent(values[i + 1]); });

      const user = getUser(req) || null;
      if (match.guard === 'auth' && !user) throw new ApiError(401, 'برای این کار باید وارد حساب خود شوید.');
      if (match.guard === 'admin' && (!user || user.role !== 'admin')) throw new ApiError(403, 'این بخش فقط برای مدیر کتابخانه است.');

      const body = (req.method === 'POST' || req.method === 'PUT' || req.method === 'PATCH')
        ? await readBody(req) : {};

      const ctx = { req, res, params, query: url.searchParams, body, user };
      const result = await match.handler(ctx);

      const headers = {};
      if (result.cookie) headers['Set-Cookie'] = result.cookie;
      return sendJSON(res, 200, { ok: true, message: result.message || null, ...result.data }, headers);
    }

    // هر چیز غیر از API → فایل استاتیک
    if (req.method === 'GET' || req.method === 'HEAD') return serveStatic(req, res, pathname);
    res.writeHead(405); res.end();

  } catch (err) {
    if (err instanceof ApiError) return sendJSON(res, err.status, { ok: false, error: err.message });
    console.error('خطای سرور:', err);
    return sendJSON(res, 500, { ok: false, error: 'خطای داخلی سرور. لطفاً دوباره تلاش کنید.' });
  }
});

server.listen(PORT, HOST, () => {
  console.log('──────────────────────────────────────────────');
  console.log('  📚 کتابخانه سپید آماده است!');
  console.log(`  ▶ آدرس:  http://localhost:${PORT}`);
  console.log('  ▶ مدیر:  admin@ketabkhooneh.ir / admin1234');
  console.log('  ▶ عضو :  member@ketabkhooneh.ir / member1234');
  console.log('──────────────────────────────────────────────');
});
